-- =====================================================================
-- WealthBridge / CapVault ingestion pipeline — RDS (PostgreSQL) schema
-- =====================================================================
-- Run this once against your RDS instance before the first Glue run.
-- No file type ("transaction" / "position") is hardcoded elsewhere —
-- everything the Glue job needs to validate a file lives in
-- dq_rule_registry, keyed by file_type.

CREATE TABLE IF NOT EXISTS ingestion_run (
    run_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id            VARCHAR(50)  NOT NULL,          -- from filename, e.g. 20260721-001
    run_date            DATE         NOT NULL DEFAULT CURRENT_DATE,
    started_at          TIMESTAMP    NOT NULL DEFAULT now(),
    finished_at         TIMESTAMP,
    total_records       BIGINT       DEFAULT 0,
    good_records        BIGINT       DEFAULT 0,
    bad_records         BIGINT       DEFAULT 0,
    status              VARCHAR(20)  NOT NULL DEFAULT 'RUNNING',  -- RUNNING | SUCCEEDED | FAILED
    run_summary         TEXT,                            -- plain-text stats summary (no Bedrock)
    error_message       TEXT
);

CREATE TABLE IF NOT EXISTS source_file (
    file_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id              UUID REFERENCES ingestion_run(run_id),
    file_name           VARCHAR(255) NOT NULL,           -- full name as landed, e.g. batch_20260721-001_transactions.csv
    file_type           VARCHAR(30)  NOT NULL,           -- derived from filename: TRANSACTION | POSITION
    s3_path             VARCHAR(500) NOT NULL,
    inferred_columns    JSONB,                           -- column name -> inferred type, captured at run time
    record_count        BIGINT       DEFAULT 0,
    good_count          BIGINT       DEFAULT 0,
    bad_count           BIGINT       DEFAULT 0,
    processed_at        TIMESTAMP    DEFAULT now(),
    status              VARCHAR(20)  DEFAULT 'PENDING'   -- PENDING | PROCESSED | FAILED
);

-- Rules are data, not code. The Glue job loads all active rules for a
-- given file_type and evaluates them generically — adding a rule means
-- inserting a row here, not touching the Glue script.
CREATE TABLE IF NOT EXISTS dq_rule_registry (
    rule_id             SERIAL PRIMARY KEY,
    file_type           VARCHAR(30)  NOT NULL,           -- TRANSACTION | POSITION | * (applies to all)
    rule_name           VARCHAR(100) NOT NULL,
    rule_type           VARCHAR(30)  NOT NULL,           -- NOT_NULL | UNIQUE | REGEX | RANGE | ALLOWED_VALUES | COMPARE_COLUMNS | CUSTOM_EXPR
    column_name         VARCHAR(100),                    -- primary column the rule applies to (nullable for multi-column rules)
    compare_column      VARCHAR(100),                    -- for COMPARE_COLUMNS rules, e.g. trade_date <= settlement_date
    parameters          JSONB        NOT NULL DEFAULT '{}'::jsonb,  -- rule-specific config, e.g. {"pattern": "^CV"}
    severity            VARCHAR(10)  NOT NULL DEFAULT 'FAIL',       -- FAIL (goes to bad) | WARN (flagged but stays good)
    is_active           BOOLEAN      NOT NULL DEFAULT true,
    created_at          TIMESTAMP    DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dq_rule_failure_summary (
    id                  SERIAL PRIMARY KEY,
    run_id              UUID REFERENCES ingestion_run(run_id),
    file_type           VARCHAR(30)  NOT NULL,
    rule_id             INTEGER REFERENCES dq_rule_registry(rule_id),
    rule_name           VARCHAR(100) NOT NULL,
    failure_count       BIGINT       NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_source_file_run_id ON source_file(run_id);
CREATE INDEX IF NOT EXISTS idx_rule_registry_file_type ON dq_rule_registry(file_type) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_failure_summary_run_id ON dq_rule_failure_summary(run_id);
