"""
Lambda: wealthbridge-run-notifier

Triggered by an EventBridge rule on Glue job state change
(SUCCEEDED / FAILED) for wealthbridge-dynamic-etl, OR can be chained
directly after the orchestrator once Glue finishes.

Stubbed for now: publishes to an SNS topic. No subscription is
attached yet -- wire up email/Slack/etc. on the topic later without
touching this function.

Environment variables:
  SNS_TOPIC_ARN
  DB_SECRET_ARN, DB_HOST, DB_PORT, DB_NAME
"""

import json
import os

import boto3
import psycopg2

sns = boto3.client("sns")
secrets = boto3.client("secretsmanager")

SNS_TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]
DB_SECRET_ARN = os.environ["DB_SECRET_ARN"]
DB_HOST = os.environ["DB_HOST"]
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ["DB_NAME"]


def get_db_connection():
    secret = json.loads(secrets.get_secret_value(SecretId=DB_SECRET_ARN)["SecretString"])
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME,
        user=secret["username"], password=secret["password"],
    )


def fetch_run(run_id: str) -> dict:
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT batch_id, total_records, good_records, bad_records,
                       status, run_summary
                FROM ingestion_run WHERE run_id = %s
                """,
                (run_id,),
            )
            row = cur.fetchone()
    finally:
        conn.close()

    if not row:
        return None
    return {
        "batch_id": row[0], "total_records": row[1], "good_records": row[2],
        "bad_records": row[3], "status": row[4], "run_summary": row[5],
    }


def handler(event, context):
    # Expects {"run_id": "..."} -- passed by whatever triggers this
    # (EventBridge rule detail, or a direct Step Functions/Lambda chain)
    run_id = event.get("run_id") or event.get("detail", {}).get("run_id")
    if not run_id:
        raise ValueError("event must include run_id")

    run = fetch_run(run_id)
    if not run:
        raise ValueError(f"No ingestion_run found for run_id={run_id}")

    message = (
        f"WealthBridge batch {run['batch_id']} — {run['status']}\n"
        f"{run['run_summary']}\n"
        f"Total: {run['total_records']} | Good: {run['good_records']} | Bad: {run['bad_records']}"
    )

    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject=f"WealthBridge batch {run['batch_id']} - {run['status']}",
        Message=message,
    )

    return {"published": True, "run_id": run_id}
