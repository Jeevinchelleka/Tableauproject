-- Seed data-driven DQ rules. file_type must match what the Lambda
-- orchestrator derives from the filename (TRANSACTION / POSITION).

-- ---------- TRANSACTION rules ----------
INSERT INTO dq_rule_registry (file_type, rule_name, rule_type, column_name, compare_column, parameters, severity) VALUES
('TRANSACTION', 'txn_id_not_null',        'NOT_NULL',        'transaction_id', NULL, '{}', 'FAIL'),
('TRANSACTION', 'txn_id_unique',          'UNIQUE',          'transaction_id', NULL, '{}', 'FAIL'),
('TRANSACTION', 'account_id_prefix',      'REGEX',           'account_id',     NULL, '{"pattern": "^CV"}', 'FAIL'),
('TRANSACTION', 'txn_type_allowed',       'ALLOWED_VALUES',  'transaction_type', NULL, '{"values": ["BUY","SELL","DIVIDEND","TRANSFER"]}', 'FAIL'),
('TRANSACTION', 'trade_before_settle',    'COMPARE_COLUMNS', 'trade_date',     'settlement_date', '{"operator": "<="}', 'FAIL'),
('TRANSACTION', 'quantity_positive',      'RANGE',           'quantity',       NULL, '{"min": 0.0000001}', 'FAIL'),
('TRANSACTION', 'price_positive',         'RANGE',           'price',          NULL, '{"min": 0.0000001}', 'FAIL'),
('TRANSACTION', 'amount_positive',        'RANGE',           'amount',         NULL, '{"min": 0.0000001}', 'FAIL'),
('TRANSACTION', 'currency_valid',         'ALLOWED_VALUES',  'currency',       NULL, '{"values": ["USD","EUR","GBP","JPY","CAD","AUD","CHF"]}', 'FAIL');

-- ---------- POSITION rules ----------
INSERT INTO dq_rule_registry (file_type, rule_name, rule_type, column_name, compare_column, parameters, severity) VALUES
('POSITION', 'pos_id_not_null',       'NOT_NULL',        'position_id',  NULL, '{}', 'FAIL'),
('POSITION', 'pos_id_unique',        'UNIQUE',           'position_id',  NULL, '{}', 'FAIL'),
('POSITION', 'account_id_prefix',    'REGEX',            'account_id',   NULL, '{"pattern": "^CV"}', 'FAIL'),
('POSITION', 'position_date_not_future', 'RANGE',        'position_date', NULL, '{"max_is_today": true}', 'FAIL'),
('POSITION', 'quantity_held_nonneg', 'RANGE',            'quantity_held', NULL, '{"min": 0}', 'FAIL'),
('POSITION', 'market_value_nonneg',  'RANGE',            'market_value',  NULL, '{"min": 0}', 'FAIL'),
('POSITION', 'currency_valid',       'ALLOWED_VALUES',   'currency',     NULL, '{"values": ["USD","EUR","GBP","JPY","CAD","AUD","CHF"]}', 'FAIL');
