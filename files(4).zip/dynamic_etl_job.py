"""
Glue job: wealthbridge-dynamic-etl

ONE job handles both transaction and position files. Nothing about
"transaction" or "position" is hardcoded here except the two literal
table-name suffixes (_good / _bad) -- the schema is inferred per file
and the validation rules are loaded from RDS per file_type, so adding
a third file type later means: add rows to dq_rule_registry, add that
file_type string to the orchestrator's classify_file_type(), done.

Job arguments (passed by the Lambda orchestrator):
  --MANIFEST_S3_PATH   s3://wealthbridge-curated/_manifests/<batch>/<run_id>.json
  --RUN_ID              uuid
  --BATCH_ID             batch id from the filename

Glue connection "wealthbridge-rds" (JDBC) must be attached to this job
so Spark can read dq_rule_registry and write metadata back.
"""

import json
import sys
from datetime import datetime

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql import Window

args = getResolvedOptions(sys.argv, ["JOB_NAME", "MANIFEST_S3_PATH", "RUN_ID", "BATCH_ID",
                                     "JDBC_URL", "JDBC_USER", "JDBC_PASSWORD",
                                     "CURATED_BUCKET", "ICEBERG_DATABASE",
                                     "NOTIFIER_FUNCTION_NAME"])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

RUN_ID = args["RUN_ID"]
BATCH_ID = args["BATCH_ID"]
CURATED_BUCKET = args["CURATED_BUCKET"]
ICEBERG_DB = args["ICEBERG_DATABASE"]

JDBC_PROPS = {
    "user": args["JDBC_USER"],
    "password": args["JDBC_PASSWORD"],
    "driver": "org.postgresql.Driver",
}
JDBC_URL = args["JDBC_URL"]


# ---------------------------------------------------------------------
# 1. Load manifest + active rules
# ---------------------------------------------------------------------
s3 = boto3.client("s3")


def read_manifest(manifest_s3_path: str) -> dict:
    bucket, key = manifest_s3_path.replace("s3://", "").split("/", 1)
    obj = s3.get_object(Bucket=bucket, Key=key)
    return json.loads(obj["Body"].read())


def mark_source_file_processed(s3_path: str):
    """Tags the landing file wb-status=processed with a timestamp, so the
    orchestrator's tag-based idempotency check skips it next run unless
    it gets re-uploaded (resend/duplicate) after this point."""
    bucket, key = s3_path.replace("s3://", "").split("/", 1)
    processed_at = datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    s3.put_object_tagging(
        Bucket=bucket,
        Key=key,
        Tagging={"TagSet": [
            {"Key": "wb-status", "Value": "processed"},
            {"Key": "wb-processed-at", "Value": processed_at},
            {"Key": "wb-run-id", "Value": RUN_ID},
        ]},
    )


def load_rules(file_type: str):
    rules_df = spark.read.jdbc(url=JDBC_URL, table="dq_rule_registry", properties=JDBC_PROPS)
    rules_df = rules_df.filter(
        (F.col("is_active") == True) & ((F.col("file_type") == file_type) | (F.col("file_type") == "*"))
    )
    return [row.asDict() for row in rules_df.collect()]


# ---------------------------------------------------------------------
# 2. Generic rule evaluator -- dispatches on rule_type, returns a
#    boolean Spark Column that is True when the record FAILS the rule.
# ---------------------------------------------------------------------
def build_fail_condition(df, rule: dict):
    rtype = rule["rule_type"]
    col_name = rule["column_name"]
    params = json.loads(rule["parameters"]) if isinstance(rule["parameters"], str) else rule["parameters"]

    if rtype == "NOT_NULL":
        return F.col(col_name).isNull()

    if rtype == "REGEX":
        pattern = params["pattern"]
        return ~F.col(col_name).rlike(pattern) | F.col(col_name).isNull()

    if rtype == "ALLOWED_VALUES":
        values = params["values"]
        return ~F.col(col_name).isin(values) | F.col(col_name).isNull()

    if rtype == "RANGE":
        cond = F.lit(False)
        if "min" in params:
            cond = cond | (F.col(col_name) < F.lit(params["min"]))
        if "max" in params:
            cond = cond | (F.col(col_name) > F.lit(params["max"]))
        if params.get("max_is_today"):
            cond = cond | (F.to_date(F.col(col_name)) > F.current_date())
        return cond | F.col(col_name).isNull()

    if rtype == "COMPARE_COLUMNS":
        other = rule["compare_column"]
        op = params.get("operator", "<=")
        left, right = F.to_date(F.col(col_name)), F.to_date(F.col(other))
        if op == "<=":
            return left > right
        if op == "<":
            return left >= right
        if op == ">=":
            return left < right
        if op == ">":
            return left <= right
        return F.lit(False)

    if rtype == "UNIQUE":
        # handled separately below (needs a window over the whole df)
        return None

    # Unknown rule type: don't silently pass -- flag every row so it's
    # visible in the failure summary rather than swallowed.
    return F.lit(True)


def apply_unique_rules(df, unique_rules: list):
    """UNIQUE needs a count-over-partition, not a per-row expression."""
    fail_cols = []
    for rule in unique_rules:
        col_name = rule["column_name"]
        w = Window.partitionBy(col_name)
        dup_col = f"_dup_{col_name}"
        df = df.withColumn(dup_col, F.count("*").over(w) > 1)
        fail_cols.append((rule, dup_col))
    return df, fail_cols


def validate_dataframe(df, rules: list):
    row_wise_rules = [r for r in rules if r["rule_type"] != "UNIQUE"]
    unique_rules = [r for r in rules if r["rule_type"] == "UNIQUE"]

    fail_flag_cols = []
    for rule in row_wise_rules:
        flag_col = f"_fail_{rule['rule_id']}"
        df = df.withColumn(flag_col, build_fail_condition(df, rule))
        fail_flag_cols.append((rule, flag_col))

    df, unique_flags = apply_unique_rules(df, unique_rules)
    fail_flag_cols += [(rule, dup_col) for rule, dup_col in unique_flags]

    # dq_status + first failing rule name / reason (kept simple: first
    # match in rule order; failure counts per rule are computed
    # separately for the summary table so no signal is lost).
    any_fail = F.lit(False)
    failed_rule_expr = F.lit(None).cast("string")
    failure_reason_expr = F.lit(None).cast("string")
    for rule, flag_col in fail_flag_cols:
        any_fail = any_fail | F.col(flag_col)
        failed_rule_expr = F.when(F.col(flag_col) & failed_rule_expr.isNull(), F.lit(rule["rule_name"])).otherwise(failed_rule_expr)
        failure_reason_expr = F.when(
            F.col(flag_col) & failure_reason_expr.isNull(),
            F.lit(f"Failed rule: {rule['rule_name']}"),
        ).otherwise(failure_reason_expr)

    df = df.withColumn("dq_status", F.when(any_fail, "BAD").otherwise("GOOD"))
    df = df.withColumn("failed_rule_id", failed_rule_expr)
    df = df.withColumn("failure_reason", failure_reason_expr)

    # per-rule failure counts, for dq_rule_failure_summary
    failure_counts = {}
    for rule, flag_col in fail_flag_cols:
        failure_counts[rule["rule_name"]] = df.filter(F.col(flag_col)).count()

    drop_cols = [flag_col for _, flag_col in fail_flag_cols]
    df = df.drop(*drop_cols)
    return df, failure_counts


# ---------------------------------------------------------------------
# 3. RDS metadata writes (plain psycopg2-style upserts via JDBC batch)
# ---------------------------------------------------------------------
def write_metadata(file_type, s3_path, total, good, bad, failure_counts):
    file_row = spark.createDataFrame([{
        "run_id": RUN_ID,
        "file_name": s3_path.rsplit("/", 1)[-1],
        "file_type": file_type,
        "s3_path": s3_path,
        "record_count": total,
        "good_count": good,
        "bad_count": bad,
        "status": "PROCESSED",
    }])
    file_row.write.jdbc(url=JDBC_URL, table="source_file", mode="append", properties=JDBC_PROPS)

    if failure_counts:
        rows = [{"run_id": RUN_ID, "file_type": file_type, "rule_name": k, "failure_count": v}
                for k, v in failure_counts.items() if v > 0]
        if rows:
            spark.createDataFrame(rows).write.jdbc(
                url=JDBC_URL, table="dq_rule_failure_summary", mode="append", properties=JDBC_PROPS
            )


def update_ingestion_run(total, good, bad, status, summary):
    # Small, targeted update -- done via a single-row overwrite through
    # a JDBC connection rather than Spark (Spark JDBC has no native
    # UPDATE support). Uses psycopg2, bundled by the Glue connection.
    import psycopg2
    conn = psycopg2.connect(dsn=JDBC_URL.replace("jdbc:", ""), user=args["JDBC_USER"], password=args["JDBC_PASSWORD"])
    with conn.cursor() as cur:
        cur.execute(
            """
            UPDATE ingestion_run
            SET total_records = %s, good_records = %s, bad_records = %s,
                status = %s, run_summary = %s, finished_at = %s
            WHERE run_id = %s
            """,
            (total, good, bad, status, summary, datetime.utcnow(), RUN_ID),
        )
    conn.commit()
    conn.close()


def notify(run_id: str):
    """Direct async invoke of the notifier Lambda -- chosen over an
    EventBridge Glue-state-change rule because that event only carries
    Glue's own jobRunId, not our run_id, and this avoids a join."""
    lambda_client = boto3.client("lambda")
    try:
        lambda_client.invoke(
            FunctionName=args["NOTIFIER_FUNCTION_NAME"],
            InvocationType="Event",
            Payload=json.dumps({"run_id": run_id}).encode("utf-8"),
        )
    except Exception as e:
        # Notification failure should not fail the whole job.
        print(f"WARN: failed to invoke notifier for run_id={run_id}: {e}")


# ---------------------------------------------------------------------
# 4. Main
# ---------------------------------------------------------------------
manifest = read_manifest(args["MANIFEST_S3_PATH"])
totals = {"total": 0, "good": 0, "bad": 0}
per_file_summary_lines = []

try:
    for entry in manifest["files"]:
        s3_path, file_type = entry["s3_path"], entry["file_type"]
        table_prefix = file_type.lower()  # transaction / position

        df = spark.read.option("header", True).option("inferSchema", True).csv(s3_path)
        rules = load_rules(file_type)
        df, failure_counts = validate_dataframe(df, rules)

        df = (
            df.withColumn("ingestion_run_id", F.lit(RUN_ID))
              .withColumn("source_file", F.lit(s3_path))
        )

        good_df = df.filter(F.col("dq_status") == "GOOD")
        bad_df = df.filter(F.col("dq_status") == "BAD")

        good_df.writeTo(f"{ICEBERG_DB}.{table_prefix}_good").append()
        bad_df.writeTo(f"{ICEBERG_DB}.{table_prefix}_bad").append()

        total, good, bad = df.count(), good_df.count(), bad_df.count()
        totals["total"] += total
        totals["good"] += good
        totals["bad"] += bad
        per_file_summary_lines.append(f"{file_type}: {total} records, {good} good, {bad} bad")

        write_metadata(file_type, s3_path, total, good, bad, failure_counts)
        mark_source_file_processed(s3_path)

    quality_pct = round(100 * totals["good"] / totals["total"], 1) if totals["total"] else 0.0
    summary = (
        f"Batch {BATCH_ID} processed {totals['total']} records. "
        f"Data quality: {quality_pct}% ({totals['good']} good / {totals['bad']} bad). "
        + " | ".join(per_file_summary_lines)
    )
    update_ingestion_run(totals["total"], totals["good"], totals["bad"], "SUCCEEDED", summary)
    notify(RUN_ID)

except Exception as e:
    update_ingestion_run(totals["total"], totals["good"], totals["bad"], "FAILED", str(e))
    notify(RUN_ID)
    raise

job.commit()
