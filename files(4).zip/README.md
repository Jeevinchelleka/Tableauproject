# WealthBridge / CapVault ingestion pipeline (v2 — no Bedrock)

## Architecture
```
CapVault CSVs (batch_<fileid>_<name>.csv)
        │
        ▼
S3 wealthbridge-landing
        │
   (daily EventBridge schedule)
        ▼
Lambda: wealthbridge-batch-orchestrator
  - lists landing bucket, parses filenames
  - groups files into batches by <fileid>
  - writes ingestion_run row (RDS)
  - writes a manifest to S3, starts Glue job
        ▼
Glue job: wealthbridge-dynamic-etl (ONE job, both file types)
  - reads manifest
  - infers CSV schema per file (no static schema config)
  - loads active rules from dq_rule_registry for that file_type
  - evaluates rules generically, splits good/bad
  - writes Iceberg tables in wealthbridge-curated
  - writes source_file + dq_rule_failure_summary + updates ingestion_run
        ▼
Lambda: wealthbridge-run-notifier (stub)
  - triggered on Glue job state change
  - reads the run from RDS, publishes to SNS (no subscription yet)
```

## Why this shape
- **Single dynamic Glue job**: file_type is a string ("TRANSACTION" / "POSITION")
  passed through the manifest, not two separate scripts. Adding a third file
  type later is a rules + orchestrator classification change, not a new job.
- **Schema inferred at read time**: `inferSchema=True` on the CSV read — no
  schema config to maintain, at the cost of Spark doing two passes over each
  file. Fine at this file size; revisit if files get large (see Known gaps).
- **Rules as data**: `dq_rule_registry` drives validation. `rule_type` values
  (`NOT_NULL`, `UNIQUE`, `REGEX`, `RANGE`, `ALLOWED_VALUES`, `COMPARE_COLUMNS`)
  are generic enough to express every rule in the original problem statement
  without hardcoding column names in the Glue script.
- **No Bedrock**: `ingestion_run.run_summary` is a plain string built from
  counts (good/bad/quality %) — no LLM call. The notifier Lambda ships that
  string as-is.

## Deploy order
1. Get a VPC + at least 2 private subnets ready (RDS + Glue connection need
   them) — pass as `VpcId` / `PrivateSubnetIds` parameters.
2. `sam deploy --guided` using `infrastructure/template.yaml`. This creates
   RDS, the Glue connection/job, both Lambdas, the SNS topic, and the
   EventBridge schedule/rule. It does **not** create `wealthbridge-landing`
   or `wealthbridge-curated` — those already exist per your setup.
3. Run `sql/01_rds_schema.sql` then `sql/02_seed_rules.sql` against the new
   RDS instance (via a bastion/Session Manager tunnel, since it's private).
4. Upload `glue/dynamic_etl_job.py` to
   `s3://wealthbridge-curated/_scripts/dynamic_etl_job.py` (the job's
   `ScriptLocation` points here).
5. Drop a couple of test files into `wealthbridge-landing` named like
   `batch_20260721001_transactions.csv` and `batch_20260721001_positions.csv`,
   then either wait for the daily schedule or invoke
   `wealthbridge-batch-orchestrator` manually to test end to end.

## Idempotency / duplicate handling
S3 object tags on the landing bucket are the source of truth:
- Once the Glue job finishes writing a file, it tags the object
  `wb-status=processed`, `wb-processed-at=<UTC ISO timestamp>`,
  `wb-run-id=<run_id>`.
- The orchestrator checks these tags before including a file in the next
  manifest. A file tagged `processed` is skipped — *unless* its S3
  `LastModified` is newer than `wb-processed-at`, meaning it was
  re-uploaded (a resend/duplicate with new content), in which case it's
  picked up again.
- Nothing is moved or deleted, so the landing bucket stays a full history;
  only the tags change.

## Completion notification
The Glue job directly invokes `wealthbridge-run-notifier` (async,
`InvocationType=Event`) at the end of the run, passing `{"run_id": ...}`.
This replaced an earlier EventBridge-based design because Glue's own
"Job State Change" event only carries Glue's internal `jobRunId`, not our
`run_id` — direct invoke avoids that join entirely.

## Known gaps to close next (flagging rather than guessing)
- **JDBC driver jar**: the Glue job needs the PostgreSQL JDBC driver
  available. The Glue Connection resource should bundle this automatically
  on Glue 4.0 — worth confirming once you run a test job.
- **Lambda psycopg2 layer**: both Lambdas import `psycopg2`, which isn't in
  the default Python runtime — attach the AWS-provided `AWSSDKPandas` layer
  (bundles psycopg2-binary) or build a custom layer.
- **VPC/subnet/security group values are still placeholders** in
  `template.yaml` (`VpcId`, `PrivateSubnetIds`, `ExistingRDSSecurityGroupId`)
  — these need to match wherever `wealthbridgemetadatards` actually lives
  (region ap-south-1, AZ ap-south-1b) so the Glue connection and both
  Lambdas can reach it.
- **RDS password**: it was shared in this chat in plaintext — rotate it in
  RDS and update the `DBPassword` deploy parameter (never commit it to
  source control; pass it via `--parameter-overrides` or a local
  `samconfig.toml` that's gitignored).
