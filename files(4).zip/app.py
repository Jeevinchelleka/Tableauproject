"""
Lambda: wealthbridge-batch-orchestrator

Triggered daily by an EventBridge schedule (e.g. cron(0 6 * * ? *)).

Responsibilities:
  1. List files in s3://wealthbridge-landing/ matching the naming
     convention: batch_<fileid>_<name>.csv
  2. Derive file_type purely from the <name> part (transactions.csv /
     positions.csv) -- no hardcoded file list, so adding a new file
     type later just means adding rules to dq_rule_registry and this
     naming convention still works unmodified.
  3. Group files by batch_id (the <fileid> token) into one manifest
     per batch.
  4. Insert one ingestion_run row per batch (status=RUNNING).
  5. Write the manifest to S3 and start the single dynamic Glue job,
     passing the manifest path + run_id as job arguments.

Requires a psycopg2 Lambda layer (or the AWS SDK for pandas layer,
which bundles it) since this talks to RDS directly.
Environment variables required:
  LANDING_BUCKET        e.g. wealthbridge-landing
  CURATED_BUCKET        e.g. wealthbridge-curated  (used for manifest storage prefix)
  GLUE_JOB_NAME         e.g. wealthbridge-dynamic-etl
  DB_SECRET_ARN         Secrets Manager ARN holding RDS credentials
  DB_HOST, DB_PORT, DB_NAME
"""

import json
import os
import re
import uuid
from datetime import date, datetime, timezone

import boto3
import psycopg2

s3 = boto3.client("s3")
glue = boto3.client("glue")
secrets = boto3.client("secretsmanager")

LANDING_BUCKET = os.environ["LANDING_BUCKET"]
CURATED_BUCKET = os.environ["CURATED_BUCKET"]
GLUE_JOB_NAME = os.environ["GLUE_JOB_NAME"]
DB_SECRET_ARN = os.environ["DB_SECRET_ARN"]
DB_HOST = os.environ["DB_HOST"]
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ["DB_NAME"]

# batch_<fileid>_<rest>.csv  -- fileid and rest are both free-form,
# split on the first two underscores only so fileid/rest can contain
# underscores themselves without breaking the parse.
FILENAME_PATTERN = re.compile(r"^batch_([^_]+)_(.+)\.csv$", re.IGNORECASE)


def classify_file_type(name_part: str) -> str | None:
    lowered = name_part.lower()
    if "transaction" in lowered:
        return "TRANSACTION"
    if "position" in lowered:
        return "POSITION"
    return None  # unrecognized -- skipped, logged, not silently dropped


def get_db_connection():
    secret = json.loads(secrets.get_secret_value(SecretId=DB_SECRET_ARN)["SecretString"])
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=secret["username"],
        password=secret["password"],
    )


def get_object_tags(key: str) -> dict:
    try:
        resp = s3.get_object_tagging(Bucket=LANDING_BUCKET, Key=key)
        return {t["Key"]: t["Value"] for t in resp.get("TagSet", [])}
    except Exception as e:
        print(f"WARN: could not read tags for {key}: {e}")
        return {}


def already_processed(key: str, last_modified) -> bool:
    """
    Tag-based idempotency: a file tagged wb-status=processed is skipped
    UNLESS it was re-uploaded after that tag was set (LastModified newer
    than wb-processed-at) -- that case is treated as a resend/duplicate
    with new content and gets reprocessed rather than silently skipped.
    """
    tags = get_object_tags(key)
    if tags.get("wb-status") != "processed":
        return False
    processed_at_raw = tags.get("wb-processed-at")
    if not processed_at_raw:
        return True  # tagged processed but no timestamp -- treat as done
    try:
        processed_at = datetime.fromisoformat(processed_at_raw.replace("Z", "+00:00"))
    except ValueError:
        return True
    return last_modified <= processed_at


def list_landing_files():
    """Returns list of (key, batch_id, file_type) for all recognized,
    not-yet-processed files."""
    paginator = s3.get_paginator("list_objects_v2")
    files = []
    for page in paginator.paginate(Bucket=LANDING_BUCKET):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            filename = key.rsplit("/", 1)[-1]
            match = FILENAME_PATTERN.match(filename)
            if not match:
                print(f"SKIP (naming convention mismatch): {key}")
                continue
            batch_id, name_part = match.group(1), match.group(2)
            file_type = classify_file_type(name_part)
            if not file_type:
                print(f"SKIP (unrecognized file type): {key}")
                continue
            if already_processed(key, obj["LastModified"]):
                print(f"SKIP (already processed, no newer upload): {key}")
                continue
            files.append({"key": key, "batch_id": batch_id, "file_type": file_type})
    return files


def group_by_batch(files):
    grouped = {}
    for f in files:
        grouped.setdefault(f["batch_id"], []).append(f)
    return grouped


def create_ingestion_run(conn, batch_id: str) -> str:
    run_id = str(uuid.uuid4())
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ingestion_run (run_id, batch_id, run_date, status)
            VALUES (%s, %s, %s, 'RUNNING')
            """,
            (run_id, batch_id, date.today()),
        )
    conn.commit()
    return run_id


def write_manifest(run_id: str, batch_id: str, files: list) -> str:
    manifest = {
        "run_id": run_id,
        "batch_id": batch_id,
        "files": [
            {
                "s3_path": f"s3://{LANDING_BUCKET}/{f['key']}",
                "file_type": f["file_type"],
            }
            for f in files
        ],
    }
    manifest_key = f"_manifests/{batch_id}/{run_id}.json"
    s3.put_object(
        Bucket=CURATED_BUCKET,
        Key=manifest_key,
        Body=json.dumps(manifest).encode("utf-8"),
        ContentType="application/json",
    )
    return f"s3://{CURATED_BUCKET}/{manifest_key}"


def start_glue_job(manifest_path: str, run_id: str, batch_id: str):
    glue.start_job_run(
        JobName=GLUE_JOB_NAME,
        Arguments={
            "--MANIFEST_S3_PATH": manifest_path,
            "--RUN_ID": run_id,
            "--BATCH_ID": batch_id,
        },
    )


def handler(event, context):
    files = list_landing_files()
    if not files:
        print("No recognized files in landing bucket. Nothing to do.")
        return {"batches_started": 0}

    grouped = group_by_batch(files)
    conn = get_db_connection()
    started = 0
    try:
        for batch_id, batch_files in grouped.items():
            run_id = create_ingestion_run(conn, batch_id)
            manifest_path = write_manifest(run_id, batch_id, batch_files)
            start_glue_job(manifest_path, run_id, batch_id)
            started += 1
            print(f"Started Glue job for batch={batch_id} run_id={run_id} "
                  f"files={len(batch_files)}")
    finally:
        conn.close()

    return {"batches_started": started}
