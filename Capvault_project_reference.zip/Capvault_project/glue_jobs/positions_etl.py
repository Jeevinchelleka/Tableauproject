"""
Positions ETL Glue Job — CapVault Pipeline
============================================
Reads position CSV data from S3 landing bucket, applies schema
enforcement, transformations, and data quality checks, then writes
good records to the position_good Iceberg table and bad records
to the position_bad Iceberg table.

Usage (run via AWS Glue):
    Glue Job Name: capvault-positions-etl
    Arguments:
        --JOB_NAME          capvault-positions-etl
        --DATABASE          iceberg_db
        --LANDING_BUCKET    wealthbridge-landing
        --CURATED_BUCKET    wealthbridge-curated
"""

import sys
from datetime import datetime

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, DateType
)

# Import shared configuration
from job_config import (
    init_glue_job, get_param, get_batch_id, iceberg_table_path, DEFAULT_PARAMS
)
from data_quality import apply_position_dq_rules, log_run_metadata


# ---------------------------------------------------------------------------
# Schema Definition
# ---------------------------------------------------------------------------

POSITION_SCHEMA = StructType([
    StructField("position_id", StringType(), True),
    StructField("account_id", StringType(), True),
    StructField("security_id", StringType(), True),
    StructField("security_name", StringType(), True),
    StructField("quantity", DoubleType(), True),
    StructField("market_value", DoubleType(), True),
    StructField("cost_basis", DoubleType(), True),
    StructField("currency", StringType(), True),
    StructField("asset_class", StringType(), True),
    StructField("position_date", StringType(), True),
    StructField("custodian", StringType(), True),
    StructField("portfolio_id", StringType(), True),
])


# ---------------------------------------------------------------------------
# Transformations
# ---------------------------------------------------------------------------

def apply_transformations(df: DataFrame, batch_id: str, source_file: str) -> DataFrame:
    """
    Apply business transformations to position data.

    Transformations:
        1. Standardise currency codes to uppercase
        2. Trim whitespace from all string columns
        3. Cast position_date to DateType
        4. Calculate unrealized_pnl = market_value - cost_basis
        5. Add audit columns: etl_timestamp, source_file, batch_id
    """
    # 1. Trim whitespace from all string columns
    string_cols = [
        f.name for f in df.schema.fields if isinstance(f.dataType, StringType)
    ]
    for col_name in string_cols:
        df = df.withColumn(col_name, F.trim(F.col(col_name)))

    # 2. Standardise currency to uppercase
    df = df.withColumn("currency", F.upper(F.col("currency")))

    # 3. Standardise asset_class to uppercase
    df = df.withColumn("asset_class", F.upper(F.col("asset_class")))

    # 4. Cast position_date string to DateType
    df = df.withColumn("position_date", F.to_date(F.col("position_date"), "yyyy-MM-dd"))

    # 5. Calculate unrealized P&L
    df = df.withColumn(
        "unrealized_pnl",
        F.round(F.col("market_value") - F.col("cost_basis"), 2)
    )

    # 6. Add audit columns
    df = (
        df
        .withColumn("etl_timestamp", F.lit(datetime.now().isoformat()))
        .withColumn("source_file", F.lit(source_file))
        .withColumn("batch_id", F.lit(batch_id))
    )

    return df


# ---------------------------------------------------------------------------
# Main ETL Logic
# ---------------------------------------------------------------------------

def main():
    """Execute the positions ETL pipeline."""

    # Initialise Glue job
    spark, glueContext, job, args = init_glue_job(
        args_list=["DATABASE", "LANDING_BUCKET", "CURATED_BUCKET"]
    )

    # Resolve parameters
    database = get_param(args, "DATABASE")
    landing_bucket = get_param(args, "LANDING_BUCKET")
    curated_bucket = get_param(args, "CURATED_BUCKET")
    batch_id = get_batch_id()

    input_path = f"s3://{landing_bucket}/positions/"
    source_file = input_path

    print(f"[INFO] Input path:    {input_path}")
    print(f"[INFO] Database:      {database}")
    print(f"[INFO] Batch ID:      {batch_id}")

    # ----- STEP 1: Read raw data from Aurora RDS -----
    print("\n[STEP 1] Reading position data from Aurora RDS...")
    from config.aws_config import (
        RDS_HOST, RDS_PORT, RDS_DATABASE_NAME, RDS_USER, get_cached_rds_password
    )
    rds_password = get_cached_rds_password()
    jdbc_url = f"jdbc:postgresql://{RDS_HOST}:{RDS_PORT}/{RDS_DATABASE_NAME}"
    raw_df = (
        spark.read.format("jdbc")
        .option("url", jdbc_url)
        .option("dbtable", "positions_landing")
        .option("user", RDS_USER)
        .option("password", rds_password)
        .option("driver", "org.postgresql.Driver")
        .option("numPartitions", "4")
        .load()
    )

    # Tag source for lineage tracking (input_file_name() is empty for JDBC sources)
    raw_df = raw_df.withColumn("_source_file", F.lit(f"jdbc:{RDS_DATABASE_NAME}.positions_landing"))

    input_count = raw_df.count()
    print(f"[INFO] Records read: {input_count}")

    if input_count == 0:
        print("[WARN] No records found. Exiting.")
        job.commit()
        return

    # ----- STEP 2: Apply transformations -----
    print("\n[STEP 2] Applying transformations...")
    transformed_df = apply_transformations(raw_df, batch_id, source_file)
    print(f"[INFO] Transformed schema:")
    transformed_df.printSchema()

    # ----- STEP 3: Apply Data Quality Rules -----
    print("\n[STEP 3] Applying data quality rules...")
    good_df, bad_df = apply_position_dq_rules(transformed_df, spark)

    good_count = good_df.count()
    bad_count = bad_df.count()

    print(f"[INFO] Good records: {good_count}")
    print(f"[INFO] Bad records:  {bad_count}")
    print(f"[INFO] Total:        {good_count + bad_count} (input: {input_count})")

    # ----- STEP 4: Write good records to Iceberg table -----
    print("\n[STEP 4] Writing good records to position_good Iceberg table...")

    good_table = iceberg_table_path(database, "position_good")

    # Drop internal columns before writing
    write_good_df = good_df.drop("_source_file")

    write_good_df.writeTo(good_table).option(
        "merge-schema", "true"
    ).append()

    print(f"[OK] Written {good_count} records to {good_table}")

    # ----- STEP 5: Write bad records to Iceberg table -----
    print("\n[STEP 5] Writing bad records to position_bad Iceberg table...")

    bad_table = iceberg_table_path(database, "position_bad")

    write_bad_df = bad_df.drop("_source_file")

    write_bad_df.writeTo(bad_table).option(
        "merge-schema", "true"
    ).append()

    print(f"[OK] Written {bad_count} records to {bad_table}")

    # ----- STEP 6: Log pipeline metrics to RDS -----
    print("\n[STEP 6] Logging metadata to RDS...")
    rule_ids = ["POS_001", "POS_002", "POS_003", "POS_004", "POS_005", "POS_006", "POS_007"]
    log_run_metadata(
        spark=spark,
        run_id=batch_id,
        file_type="position",
        file_name="positions_data",
        s3_path=input_path,
        total_count=input_count,
        good_count=good_count,
        bad_count=bad_count,
        bad_df=bad_df,
        rule_ids=rule_ids
    )

    # ----- Summary -----
    print(f"\n{'='*60}")
    print(f"  Positions ETL Complete")
    print(f"{'='*60}")
    print(f"  Batch ID:      {batch_id}")
    print(f"  Input records: {input_count}")
    print(f"  Good records:  {good_count} ({100*good_count/input_count:.1f}%)")
    print(f"  Bad records:   {bad_count} ({100*bad_count/input_count:.1f}%)")
    print(f"  Data loss:     {input_count - good_count - bad_count}")
    print(f"{'='*60}")

    # Commit job
    job.commit()
    print("[OK] Glue job committed successfully.")


if __name__ == "__main__":
    main()
