"""
Data Quality Rule Engine -- CapVault Pipeline
===============================================
Reusable data quality (DQ) framework that validates records against
configurable rules and separates data into good/bad DataFrames.

Each bad record includes a 'dq_failure_reason' column listing all
rules that failed, enabling root cause analysis.

Rule Types:
    - NOT_NULL:       Field must not be null or empty string
    - POSITIVE:       Numeric field must be > 0
    - NON_NEGATIVE:   Numeric field must be >= 0
    - VALID_VALUES:   Field must be one of the allowed values
    - VALID_DATE:     Date field must not be in the future
    - DATE_ORDER:     date_field_1 must be <= date_field_2
    - NOT_EMPTY:      String field must not be empty after trimming
"""

from datetime import datetime
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F


# ---------------------------------------------------------------------------
# Valid Values (shared across rules)
# ---------------------------------------------------------------------------

VALID_CURRENCIES = ["USD", "EUR", "GBP", "INR", "JPY"]
VALID_TRANSACTION_TYPES = ["BUY", "SELL", "DIVIDEND", "TRANSFER"]
VALID_ASSET_CLASSES = ["EQUITY", "FIXED_INCOME", "COMMODITY", "FOREX", "DERIVATIVE"]


# ---------------------------------------------------------------------------
# Rule Definitions
# ---------------------------------------------------------------------------

def rule_not_null(df: DataFrame, field: str, rule_name: str) -> DataFrame:
    """
    Check that a field is not null and not empty string.
    Adds a column '{rule_name}' with the failure reason or null if passed.
    """
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(field).isNull()) | (F.trim(F.col(field)) == ""),
            F.lit(f"{rule_name}: {field} is null or empty")
        ).otherwise(F.lit(None).cast("string"))
    )


def rule_positive(df: DataFrame, field: str, rule_name: str) -> DataFrame:
    """Check that a numeric field is strictly positive (> 0)."""
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(field).isNull()) | (F.col(field) <= 0),
            F.lit(f"{rule_name}: {field} must be > 0")
        ).otherwise(F.lit(None).cast("string"))
    )


def rule_non_negative(df: DataFrame, field: str, rule_name: str) -> DataFrame:
    """Check that a numeric field is non-negative (>= 0)."""
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(field).isNull()) | (F.col(field) < 0),
            F.lit(f"{rule_name}: {field} must be >= 0")
        ).otherwise(F.lit(None).cast("string"))
    )


def rule_valid_values(df: DataFrame, field: str, valid_values: list, rule_name: str) -> DataFrame:
    """Check that a field value is one of the allowed values."""
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(field).isNull()) | (~F.upper(F.col(field)).isin(valid_values)),
            F.lit(f"{rule_name}: {field} not in {valid_values}")
        ).otherwise(F.lit(None).cast("string"))
    )


def rule_valid_date_not_future(df: DataFrame, field: str, rule_name: str) -> DataFrame:
    """Check that a date field is not in the future."""
    today = datetime.now().strftime("%Y-%m-%d")
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(field).isNotNull()) & (F.col(field) > F.lit(today).cast("date")),
            F.lit(f"{rule_name}: {field} is in the future")
        ).otherwise(F.lit(None).cast("string"))
    )


def rule_date_order(df: DataFrame, date_field_1: str, date_field_2: str, rule_name: str) -> DataFrame:
    """Check that date_field_1 <= date_field_2 (e.g., trade_date <= settlement_date)."""
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(date_field_1).isNotNull()) &
            (F.col(date_field_2).isNotNull()) &
            (F.col(date_field_1) > F.col(date_field_2)),
            F.lit(f"{rule_name}: {date_field_1} must be <= {date_field_2}")
        ).otherwise(F.lit(None).cast("string"))
    )
def rule_unique(df: DataFrame, field: str, rule_name: str) -> DataFrame:
    """Check that a field is unique within the DataFrame."""
    from pyspark.sql.window import Window
    window_spec = Window.partitionBy(field)
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(field).isNotNull()) & (F.count(field).over(window_spec) > 1),
            F.lit(f"{rule_name}: {field} must be unique")
        ).otherwise(F.lit(None).cast("string"))
    )


def rule_prefix(df: DataFrame, field: str, prefix: str, rule_name: str) -> DataFrame:
    """Check that a string field starts with a specific prefix."""
    return df.withColumn(
        rule_name,
        F.when(
            (F.col(field).isNull()) | (~F.col(field).startswith(prefix)),
            F.lit(f"{rule_name}: {field} must start with '{prefix}'")
        ).otherwise(F.lit(None).cast("string"))
    )


def rule_positive_amounts(df: DataFrame, fields: list, rule_name: str) -> DataFrame:
    """Check that a list of numeric fields are all strictly greater than zero."""
    cond = F.col(fields[0]).isNull() | (F.col(fields[0]) <= 0)
    for field in fields[1:]:
        cond = cond | F.col(field).isNull() | (F.col(field) <= 0)
    return df.withColumn(
        rule_name,
        F.when(
            cond,
            F.lit(f"{rule_name}: {', '.join(fields)} must be > 0")
        ).otherwise(F.lit(None).cast("string"))
    )


def fetch_rules_from_rds(spark: SparkSession, table_type: str) -> list:
    """
    Fetch active rules for a given table type ('position' or 'transaction')
    from the RDS PostgreSQL dq_rule_registry table.
    """
    try:
        from config.aws_config import (
            RDS_HOST, RDS_PORT, RDS_DATABASE_NAME, RDS_USER, get_cached_rds_password
        )
        rds_password = get_cached_rds_password()
        if not rds_password:
            print("[WARN] RDS password unavailable. Falling back to local rules.")
            return []

        jdbc_url = f"jdbc:postgresql://{RDS_HOST}:{RDS_PORT}/{RDS_DATABASE_NAME}"
        print(f"[INFO] Fetching rules from RDS table 'dq_rule_registry' in {RDS_DATABASE_NAME}...")

        # Read from PostgreSQL using Spark JDBC
        rules_df = spark.read.jdbc(
            url=jdbc_url,
            table="dq_rule_registry",
            properties={
                "user": RDS_USER,
                "password": rds_password,
                "driver": "org.postgresql.Driver",
                "ssl": "true",
                "sslmode": "require"
            }
        )

        # Filter for active rules of the specified table_type
        active_rules = rules_df.filter(
            (F.col("table_type") == table_type) & (F.col("is_active") == True)
        ).collect()

        # Convert Spark Rows to dicts
        rules_list = [row.asDict() for row in active_rules]
        print(f"[INFO] Successfully fetched {len(rules_list)} active rules from RDS for table type: {table_type}")
        return rules_list
    except Exception as e:
        print(f"[ERROR] Failed to fetch rules from RDS: {e}")
        print("[WARN] Falling back to local hardcoded rule definitions")
        return []


# ---------------------------------------------------------------------------
# Aggregate DQ Results
# ---------------------------------------------------------------------------

def separate_good_bad(df: DataFrame, rule_columns: list) -> tuple:
    """
    Separate a DataFrame into good and bad records based on DQ rule results.

    Good records: All rule columns are null (no failures).
    Bad records:  At least one rule column is not null.
    Bad records include a 'dq_failure_reason' column concatenating all failures.

    Args:
        df: DataFrame with DQ rule columns added
        rule_columns: List of column names added by DQ rules

    Returns:
        Tuple of (good_df, bad_df)
    """
    # Build a combined failure reason by concatenating all non-null rule results
    failure_conditions = [F.col(rc) for rc in rule_columns]

    # Create dq_failure_reason: concat_ws all non-null failure columns
    df = df.withColumn(
        "dq_failure_reason",
        F.concat_ws(" | ", *failure_conditions)
    )

    # Good records: dq_failure_reason is empty
    good_df = df.filter(F.col("dq_failure_reason") == "")
    good_df = good_df.drop("dq_failure_reason", *rule_columns)

    # Bad records: dq_failure_reason is not empty
    bad_df = df.filter(F.col("dq_failure_reason") != "")
    bad_df = bad_df.drop(*rule_columns)  # Keep dq_failure_reason, drop individual rule cols

    return good_df, bad_df


# ---------------------------------------------------------------------------
# Position DQ Rules
# ---------------------------------------------------------------------------

def apply_position_dq_rules(df: DataFrame, spark: SparkSession = None) -> tuple:
    """
    Apply data quality rules for position data.
    If spark is provided, loads rules dynamically from RDS. Otherwise falls back to local.
    """
    active_rules = []
    if spark is not None:
        active_rules = fetch_rules_from_rds(spark, "position")
    
    if not active_rules:
        # Fallback to local hardcoded rule definitions matching the DB registry
        active_rules = [
            {"rule_id": "POS_001", "rule_name": "position_id_not_null"},
            {"rule_id": "POS_002", "rule_name": "position_id_unique"},
            {"rule_id": "POS_003", "rule_name": "account_id_prefix"},
            {"rule_id": "POS_004", "rule_name": "position_date_valid"},
            {"rule_id": "POS_005", "rule_name": "quantity_held_valid"},
            {"rule_id": "POS_006", "rule_name": "market_value_valid"},
            {"rule_id": "POS_007", "rule_name": "currency_valid"},
        ]

    rule_columns = []

    for rule in active_rules:
        rule_id = rule["rule_id"]
        rule_name = rule["rule_name"]

        if rule_name == "position_id_not_null":
            df = rule_not_null(df, "position_id", rule_id)
        elif rule_name == "position_id_unique":
            df = rule_unique(df, "position_id", rule_id)
        elif rule_name == "account_id_prefix":
            df = rule_prefix(df, "account_id", "CV", rule_id)
        elif rule_name == "position_date_valid":
            df = rule_valid_date_not_future(df, "position_date", rule_id)
        elif rule_name == "quantity_held_valid":
            # Quantity cannot be negative (>= 0)
            df = rule_non_negative(df, "quantity", rule_id)
        elif rule_name == "market_value_valid":
            # Market value cannot be negative (>= 0)
            df = rule_non_negative(df, "market_value", rule_id)
        elif rule_name == "currency_valid":
            df = rule_valid_values(df, "currency", VALID_CURRENCIES, rule_id)
        else:
            print(f"[WARN] Unknown position rule: {rule_name}, skipping.")
            continue

        rule_columns.append(rule_id)

    print(f"[DQ] Applied {len(rule_columns)} rules to positions data")
    return separate_good_bad(df, rule_columns)


# ---------------------------------------------------------------------------
# Transaction DQ Rules
# ---------------------------------------------------------------------------

def apply_transaction_dq_rules(df: DataFrame, spark: SparkSession = None) -> tuple:
    """
    Apply all data quality rules for transaction data.
    If spark is provided, loads rules dynamically from RDS. Otherwise falls back to local.
    """
    active_rules = []
    if spark is not None:
        active_rules = fetch_rules_from_rds(spark, "transaction")

    if not active_rules:
        # Fallback to local hardcoded rule definitions matching the DB registry
        active_rules = [
            {"rule_id": "TXN_001", "rule_name": "txn_id_not_null"},
            {"rule_id": "TXN_002", "rule_name": "txn_id_unique"},
            {"rule_id": "TXN_003", "rule_name": "account_id_prefix"},
            {"rule_id": "TXN_004", "rule_name": "txn_type_valid"},
            {"rule_id": "TXN_005", "rule_name": "trade_settlement_date"},
            {"rule_id": "TXN_006", "rule_name": "positive_amounts"},
            {"rule_id": "TXN_007", "rule_name": "currency_valid"},
        ]

    rule_columns = []

    for rule in active_rules:
        rule_id = rule["rule_id"]
        rule_name = rule["rule_name"]

        if rule_name == "txn_id_not_null":
            df = rule_not_null(df, "transaction_id", rule_id)
        elif rule_name == "txn_id_unique":
            df = rule_unique(df, "transaction_id", rule_id)
        elif rule_name == "account_id_prefix":
            df = rule_prefix(df, "account_id", "CV", rule_id)
        elif rule_name == "txn_type_valid":
            df = rule_valid_values(df, "transaction_type", VALID_TRANSACTION_TYPES, rule_id)
        elif rule_name == "trade_settlement_date":
            df = rule_date_order(df, "trade_date", "settlement_date", rule_id)
        elif rule_name == "positive_amounts":
            df = rule_positive_amounts(df, ["quantity", "price", "amount"], rule_id)
        elif rule_name == "currency_valid":
            df = rule_valid_values(df, "currency", VALID_CURRENCIES, rule_id)
        else:
            print(f"[WARN] Unknown transaction rule: {rule_name}, skipping.")
            continue

        rule_columns.append(rule_id)

    print(f"[DQ] Applied {len(rule_columns)} rules to transactions data")
    return separate_good_bad(df, rule_columns)


def log_run_metadata(spark: SparkSession, run_id: str, file_type: str, file_name: str, s3_path: str, total_count: int, good_count: int, bad_count: int, bad_df: DataFrame = None, rule_ids: list = None):
    """
    Log ingestion metrics and data quality failure summary to RDS PostgreSQL.
    Uses Secrets Manager for credentials — never reads plaintext passwords.
    """
    try:
        from config.aws_config import (
            RDS_HOST, RDS_PORT, RDS_DATABASE_NAME, RDS_USER, get_cached_rds_password
        )
        rds_password = get_cached_rds_password()
        if not rds_password:
            print("[WARN] RDS password unavailable. Skipping RDS logging.")
            return

        import psycopg2
        from datetime import datetime

        print(f"[INFO] Logging metadata for run {run_id} to RDS...")
        conn = psycopg2.connect(
            host=RDS_HOST,
            port=RDS_PORT,
            database=RDS_DATABASE_NAME,
            user=RDS_USER,
            password=rds_password,
            sslmode="require"
        )
        cur = conn.cursor()

        # 1. Log ingestion run
        cur.execute(
            """
            INSERT INTO ingestion_run (run_id, batch_date, processing_ts, total_records, good_records, bad_records, processing_status, ai_summary)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                run_id,
                datetime.now().date(),
                datetime.now(),
                total_count,
                good_count,
                bad_count,
                "COMPLETED" if bad_count == 0 else "PARTIAL_SUCCESS",
                f"Ingestion completed with {good_count} good records and {bad_count} bad records."
            )
        )

        # 2. Log source file details
        cur.execute(
            """
            INSERT INTO source_file (run_id, file_name, file_type, s3_path, record_count, good_count, bad_count, processing_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                run_id,
                file_name,
                file_type,
                s3_path,
                total_count,
                good_count,
                bad_count,
                datetime.now().date()
            )
        )

        # 3. Log data quality rule failures if bad records exist
        if bad_count > 0 and bad_df is not None and rule_ids:
            for rule_id in rule_ids:
                fail_cnt = bad_df.filter(F.col("dq_failure_reason").contains(rule_id)).count()
                if fail_cnt > 0:
                    cur.execute(
                        """
                        INSERT INTO dq_rule_failure_summary (run_id, rule_id, failure_count, created_at)
                        VALUES (%s, %s, %s, %s)
                        """,
                        (run_id, rule_id, fail_cnt, datetime.now())
                    )

        conn.commit()
        cur.close()
        conn.close()
        print(f"[OK] Successfully logged all run metadata to RDS.")
    except Exception as e:
        print(f"[ERROR] Failed to log run metadata to RDS: {e}")

