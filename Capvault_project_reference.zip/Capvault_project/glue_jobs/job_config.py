"""
Glue Job Configuration for CapVault Pipeline
==============================================
Shared configuration and helper functions for all Glue ETL jobs.
Handles Spark session setup with Iceberg support, job parameters,
and logging configuration.
"""

import sys
from datetime import datetime
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SparkSession


# ---------------------------------------------------------------------------
# Default Job Parameters
# ---------------------------------------------------------------------------

DEFAULT_PARAMS = {
    "JOB_NAME": "capvault-etl",
    "DATABASE": "iceberg_db",
    "LANDING_BUCKET": "wealthbridge-landing",
    "CURATED_BUCKET": "wealthbridge-curated",
    "WAREHOUSE_PATH": "s3://wealthbridge-curated/iceberg-warehouse/",
}


# ---------------------------------------------------------------------------
# Spark / Glue Context Initialisation
# ---------------------------------------------------------------------------

def init_glue_job(args_list=None):
    """
    Initialise a Glue job with Iceberg-enabled Spark session.

    Args:
        args_list: List of additional argument names to resolve.
                   'JOB_NAME' is always included.

    Returns:
        Tuple of (spark, glueContext, job, args)
    """
    if args_list is None:
        args_list = []

    # Always include JOB_NAME and WAREHOUSE_PATH
    resolve_args = list(set(["JOB_NAME", "WAREHOUSE_PATH"] + args_list))

    args = getResolvedOptions(sys.argv, resolve_args)

    # Resolve warehouse path: prefer job arg, fall back to default
    warehouse_path = args.get("WAREHOUSE_PATH") or DEFAULT_PARAMS["WAREHOUSE_PATH"]

    # Create Spark session with Iceberg catalog configuration
    spark = (
        SparkSession.builder
        .config("spark.sql.catalog.glue_catalog", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.glue_catalog.warehouse", warehouse_path)
        .config("spark.sql.catalog.glue_catalog.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")
        .config("spark.sql.catalog.glue_catalog.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
        .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
        .config("spark.sql.defaultCatalog", "glue_catalog")
        .getOrCreate()
    )

    sc = spark.sparkContext
    glueContext = GlueContext(sc)
    job = Job(glueContext)
    job.init(args["JOB_NAME"], args)

    # Set log level
    sc.setLogLevel("WARN")

    print(f"[INFO] Glue job initialised: {args['JOB_NAME']}")
    print(f"[INFO] Spark version: {spark.version}")
    print(f"[INFO] Iceberg warehouse: {warehouse_path}")
    print(f"[INFO] Timestamp: {datetime.now().isoformat()}")

    return spark, glueContext, job, args


def get_param(args: dict, key: str, default: str = None) -> str:
    """
    Get a job parameter with a fallback to defaults.

    Args:
        args: Resolved arguments dict from getResolvedOptions
        key: Parameter name
        default: Override default value

    Returns:
        Parameter value as string.
    """
    if key in args and args[key]:
        return args[key]
    if default is not None:
        return default
    return DEFAULT_PARAMS.get(key, "")


def get_batch_id() -> str:
    """Generate a unique batch ID based on current timestamp."""
    return datetime.now().strftime("batch_%Y%m%d_%H%M%S")


def iceberg_table_path(database: str, table: str) -> str:
    """
    Build the fully qualified Iceberg table path for Spark SQL.

    Args:
        database: Glue database name
        table: Glue table name

    Returns:
        Fully qualified table name: 'glue_catalog.database.table'
    """
    return f"glue_catalog.{database}.{table}"
