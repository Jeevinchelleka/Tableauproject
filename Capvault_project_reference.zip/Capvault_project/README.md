# CapVault — Financial Data Pipeline on AWS

A production-grade data pipeline for ingesting, transforming, and curating **positions** and **transactions** data using AWS services.

## Architecture

```
S3 Landing → Glue ETL (PySpark) → Data Quality → Iceberg Tables (S3 Curated)
```

## AWS Resources

| Resource | Name |
|----------|------|
| S3 Landing Bucket | `wealthbridge-landing` |
| S3 Curated Bucket | `wealthbridge-curated` |
| Glue Database | `iceberg_db` |
| Glue Tables | `position_good`, `position_bad`, `transaction_good`, `transaction_bad` |
| Aurora RDS | `wealthbridgemetadatards` |
| Region | `ap-south-1` |

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure AWS credentials
# Set up AWS CLI or configure config/aws_config.py

# 3. Verify AWS connectivity
python scripts/verify_aws.py

# 4. Generate sample data
python scripts/generate_sample_data.py

# 5. Upload to S3
python scripts/s3_upload.py
```

## Project Structure

```
Capvault_project/
├── config/
│   └── aws_config.py            # AWS connection configuration
├── data/
│   ├── positions/               # Generated sample position CSVs
│   └── transactions/            # Generated sample transaction CSVs
├── glue_jobs/
│   ├── job_config.py            # Glue job configuration
│   ├── data_quality.py          # Data quality rule engine
│   ├── positions_etl.py         # Positions ETL PySpark job
│   └── transactions_etl.py     # Transactions ETL PySpark job
├── scripts/
│   ├── generate_sample_data.py  # Sample data generator
│   ├── verify_aws.py            # AWS connectivity checker
│   ├── s3_upload.py             # S3 data upload
│   ├── s3_utils.py              # S3 utility functions
│   ├── deploy_glue_jobs.py      # Deploy Glue jobs to AWS
│   ├── run_pipeline.py          # End-to-end pipeline runner
│   ├── validate_results.py      # Output validation
│   └── monitor_jobs.py          # Glue job monitoring
├── tests/
│   ├── test_data_quality.py     # DQ rule unit tests
│   └── test_transformations.py  # Transformation tests
├── requirements.txt
└── README.md
```
