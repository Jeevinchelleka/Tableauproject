"""
Unit Tests for ETL Transformations
=====================================
Tests the business logic transformations in positions_etl.py and
transactions_etl.py using pytest.
If PySpark is not installed locally, tests will be skipped gracefully.

Usage:
    pytest tests/test_transformations.py -v
"""

import sys
import os
import pytest

# Add project root and glue_jobs to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, "glue_jobs"))

# Check if PySpark is available
pyspark_available = False
try:
    from pyspark.sql import SparkSession
    from pyspark.sql import functions as F
    from pyspark.sql.types import (
        StructType, StructField, StringType, DoubleType
    )
    import glue_jobs.positions_etl as pos_etl
    import glue_jobs.transactions_etl as txn_etl
    pyspark_available = True
except ImportError:
    pass

pytestmark = pytest.mark.skipif(
    not pyspark_available,
    reason="PySpark is not installed locally (Glue runtime only)"
)


@pytest.fixture(scope="module")
def spark():
    """Create a local Spark session for testing."""
    session = (
        SparkSession.builder
        .master("local[*]")
        .appName("capvault-transformation-unit-tests")
        .getOrCreate()
    )
    yield session
    session.stop()


def test_position_transformations(spark):
    """Test standardizations and unrealized PnL calculations for positions."""
    # Create sample raw position data
    schema = StructType([
        StructField("position_id", StringType(), True),
        StructField("account_id", StringType(), True),
        StructField("security_id", StringType(), True),
        StructField("security_name", StringType(), True),
        StructField("quantity", DoubleType(), True),
        StructField("market_value", DoubleType(), True),
        StructField("cost_basis", DoubleType(), True),
        StructField("currency", StringType(), True),
        StructField("asset_class", StringType(), True),
        StructField("position_date", StringType(), True),
        StructField("custodian", StringType(), True),
        StructField("portfolio_id", StringType(), True),
    ])
    
    data = [
        ("POS-001", "ACC-01", "AAPL", " Apple Inc. ", 100.0, 15000.0, 12000.0, "usd", "Equity", "2025-01-15", "GS", "PF-01")
    ]
    df = spark.createDataFrame(data, schema)
    
    transformed_df = pos_etl.apply_transformations(
        df, batch_id="test_batch", source_file="test_source.csv"
    )
    result = transformed_df.first()
    
    # 1. Trimming check
    assert result["security_name"] == "Apple Inc."
    # 2. Currency case check
    assert result["currency"] == "USD"
    # 3. Asset class case check
    assert result["asset_class"] == "EQUITY"
    # 4. Date formatting check
    assert str(result["position_date"]) == "2025-01-15"
    # 5. PnL calculation check: 15000.0 - 12000.0 = 3000.0
    assert result["unrealized_pnl"] == 3000.0
    # 6. Audit columns check
    assert result["batch_id"] == "test_batch"
    assert result["source_file"] == "test_source.csv"
    assert result["etl_timestamp"] is not None


def test_transaction_transformations(spark):
    """Test standardizations and total value calculations for transactions."""
    schema = StructType([
        StructField("transaction_id", StringType(), True),
        StructField("account_id", StringType(), True),
        StructField("security_id", StringType(), True),
        StructField("security_name", StringType(), True),
        StructField("transaction_type", StringType(), True),
        StructField("quantity", DoubleType(), True),
        StructField("price", DoubleType(), True),
        StructField("amount", DoubleType(), True),
        StructField("currency", StringType(), True),
        StructField("trade_date", StringType(), True),
        StructField("settlement_date", StringType(), True),
        StructField("broker", StringType(), True),
        StructField("portfolio_id", StringType(), True),
    ])
    
    data = [
        ("TXN-001", "ACC-01", "AAPL", " Apple Inc. ", "buy", 10.0, 150.0, 1500.0, "usd", "2025-01-15", "2025-01-17", "GS", "PF-01")
    ]
    df = spark.createDataFrame(data, schema)
    
    transformed_df = txn_etl.apply_transformations(
        df, batch_id="test_batch", source_file="test_source.csv"
    )
    result = transformed_df.first()
    
    # 1. Trimming check
    assert result["security_name"] == "Apple Inc."
    # 2. Currency case check
    assert result["currency"] == "USD"
    # 3. Transaction type case check
    assert result["transaction_type"] == "BUY"
    # 4. Date formatting check
    assert str(result["trade_date"]) == "2025-01-15"
    assert str(result["settlement_date"]) == "2025-01-17"
    # 5. Total value calculation check: 10.0 * 150.0 = 1500.0
    assert result["total_value"] == 1500.0
    # 6. Audit columns check
    assert result["batch_id"] == "test_batch"
    assert result["source_file"] == "test_source.csv"
    assert result["etl_timestamp"] is not None
