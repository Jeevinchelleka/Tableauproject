"""
Unit Tests for Data Quality Rule Engine
==========================================
Tests the validation rules in glue_jobs/data_quality.py using pytest.
If PySpark is not installed locally, tests will be skipped gracefully.

Usage:
    pytest tests/test_data_quality.py -v
"""

import sys
import os
import pytest

# Add project root and glue_jobs to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, "glue_jobs"))

# Check if PySpark is available
pyspark_available = False
try:
    from pyspark.sql import SparkSession
    from pyspark.sql import functions as F
    from pyspark.sql.types import (
        StructType, StructField, StringType, DoubleType, DateType
    )
    import glue_jobs.data_quality as dq
    pyspark_available = True
except ImportError:
    pass

pytestmark = pytest.mark.skipif(
    not pyspark_available,
    reason="PySpark is not installed locally (Glue runtime only)"
)


@pytest.fixture(scope="module")
def spark():
    """Create a local Spark session for testing."""
    session = (
        SparkSession.builder
        .master("local[*]")
        .appName("capvault-dq-unit-tests")
        .getOrCreate()
    )
    yield session
    session.stop()


def test_rule_not_null(spark):
    """Test rule_not_null validates missing or empty values."""
    schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", StringType(), True)
    ])
    data = [
        ("1", "hello"),
        ("2", ""),
        ("3", "   "),
        ("4", None)
    ]
    df = spark.createDataFrame(data, schema)
    
    res_df = dq.rule_not_null(df, "val", "RULE_NOT_NULL")
    results = res_df.collect()
    
    # "1" should pass (RULE_NOT_NULL is null)
    assert results[0]["RULE_NOT_NULL"] is None
    # "2" (empty), "3" (spaces), "4" (None) should fail
    assert results[1]["RULE_NOT_NULL"] is not None
    assert results[2]["RULE_NOT_NULL"] is not None
    assert results[3]["RULE_NOT_NULL"] is not None


def test_rule_positive(spark):
    """Test rule_positive validates values > 0."""
    schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", DoubleType(), True)
    ])
    data = [
        ("1", 10.5),
        ("2", 0.0),
        ("3", -1.5),
        ("4", None)
    ]
    df = spark.createDataFrame(data, schema)
    
    res_df = dq.rule_positive(df, "val", "RULE_POSITIVE")
    results = res_df.collect()
    
    assert results[0]["RULE_POSITIVE"] is None
    assert results[1]["RULE_POSITIVE"] is not None
    assert results[2]["RULE_POSITIVE"] is not None
    assert results[3]["RULE_POSITIVE"] is not None


def test_rule_non_negative(spark):
    """Test rule_non_negative validates values >= 0."""
    schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", DoubleType(), True)
    ])
    data = [
        ("1", 10.5),
        ("2", 0.0),
        ("3", -1.5),
        ("4", None)
    ]
    df = spark.createDataFrame(data, schema)
    
    res_df = dq.rule_non_negative(df, "val", "RULE_NON_NEGATIVE")
    results = res_df.collect()
    
    assert results[0]["RULE_NON_NEGATIVE"] is None
    assert results[1]["RULE_NON_NEGATIVE"] is None
    assert results[2]["RULE_NON_NEGATIVE"] is not None
    assert results[3]["RULE_NON_NEGATIVE"] is not None


def test_rule_valid_values(spark):
    """Test rule_valid_values validates enums (case insensitive)."""
    schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", StringType(), True)
    ])
    data = [
        ("1", "USD"),
        ("2", "usd"),
        ("3", "INR"),
        ("4", "CAD"),
        ("5", None)
    ]
    df = spark.createDataFrame(data, schema)
    valid_list = ["USD", "INR", "GBP"]
    
    res_df = dq.rule_valid_values(df, "val", valid_list, "RULE_VALID_VALUES")
    results = res_df.collect()
    
    assert results[0]["RULE_VALID_VALUES"] is None
    assert results[1]["RULE_VALID_VALUES"] is None  # standardizes case
    assert static_check_fails_values(results[2]["RULE_VALID_VALUES"])
    assert results[3]["RULE_VALID_VALUES"] is not None
    assert results[4]["RULE_VALID_VALUES"] is not None


def static_check_fails_values(val):
    return val is None


def test_rule_date_order(spark):
    """Test rule_date_order validates date_1 <= date_2."""
    schema = StructType([
        StructField("id", StringType(), True),
        StructField("d1", StringType(), True),
        StructField("d2", StringType(), True)
    ])
    data = [
        ("1", "2025-01-01", "2025-01-02"),
        ("2", "2025-01-01", "2025-01-01"),
        ("3", "2025-01-02", "2025-01-01"),
        ("4", "2025-01-01", None),
        ("5", None, "2025-01-01")
    ]
    df = spark.createDataFrame(data, schema)
    # Cast to DateType
    df = df.withColumn("d1", F.to_date(F.col("d1"), "yyyy-MM-dd"))
    df = df.withColumn("d2", F.to_date(F.col("d2"), "yyyy-MM-dd"))
    
    res_df = dq.rule_date_order(df, "d1", "d2", "RULE_DATE_ORDER")
    results = res_df.collect()
    
    assert results[0]["RULE_DATE_ORDER"] is None
    assert results[1]["RULE_DATE_ORDER"] is None
    assert results[2]["RULE_DATE_ORDER"] is not None
    assert results[3]["RULE_DATE_ORDER"] is None  # Passes if one date is null
    assert results[4]["RULE_DATE_ORDER"] is None
