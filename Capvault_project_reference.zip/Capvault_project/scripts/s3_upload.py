"""
S3 Upload Script for CapVault Pipeline
========================================
Uploads generated sample data from the local data/ directory
to the S3 landing bucket (wealthbridge-landing) with Hive-style
partitioning and metadata tags.

Usage:
    python scripts/s3_upload.py
    python scripts/s3_upload.py --data-type positions
    python scripts/s3_upload.py --data-type transactions
    python scripts/s3_upload.py --clean  (delete existing data first)
"""

import sys
import os
import argparse
import hashlib
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    S3_LANDING_BUCKET,
    S3_POSITIONS_PREFIX,
    S3_TRANSACTIONS_PREFIX,
)
from scripts.s3_utils import delete_prefix, print_bucket_summary


def get_s3_client():
    """Create and return an S3 client."""
    return boto3.client("s3", region_name=AWS_REGION)


def calculate_md5(filepath: str) -> str:
    """Calculate MD5 hash of a file for integrity verification."""
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def count_csv_records(filepath: str) -> int:
    """Count the number of data records in a CSV file (excluding header)."""
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    return max(0, len(lines) - 1)  # Exclude header


def upload_file(
    s3_client,
    local_path: str,
    bucket: str,
    s3_key: str,
    metadata: dict = None
) -> bool:
    """
    Upload a single file to S3 with optional metadata tags.

    Args:
        s3_client: boto3 S3 client
        local_path: Path to local file
        bucket: S3 bucket name
        s3_key: Destination S3 key
        metadata: Optional dict of metadata to attach

    Returns:
        True if upload was successful.
    """
    try:
        extra_args = {}
        if metadata:
            extra_args["Metadata"] = {k: str(v) for k, v in metadata.items()}

        s3_client.upload_file(
            Filename=local_path,
            Bucket=bucket,
            Key=s3_key,
            ExtraArgs=extra_args,
        )

        file_size = os.path.getsize(local_path)
        size_kb = file_size / 1024
        print(f"  [OK] Uploaded: s3://{bucket}/{s3_key} ({size_kb:.1f} KB)")
        return True

    except ClientError as e:
        print(f"  [FAIL] Failed to upload {local_path}: {e}")
        return False
    except FileNotFoundError:
        print(f"  [FAIL] File not found: {local_path}")
        return False


def upload_data_directory(
    data_type: str,
    local_data_dir: str,
    s3_prefix: str,
) -> dict:
    """
    Upload all CSV files from a local data directory to S3,
    preserving the Hive-style partition structure.

    Args:
        data_type: 'positions' or 'transactions'
        local_data_dir: Local directory containing partitioned CSV files
        s3_prefix: S3 key prefix (e.g., 'positions/' or 'transactions/')

    Returns:
        Dict with upload statistics.
    """
    s3 = get_s3_client()
    stats = {
        "total_files": 0,
        "uploaded": 0,
        "failed": 0,
        "total_records": 0,
        "total_bytes": 0,
    }

    if not os.path.exists(local_data_dir):
        print(f"  [WARN] Data directory does not exist: {local_data_dir}")
        return stats

    print(f"\n  Uploading {data_type} from: {local_data_dir}")
    print(f"  Destination: s3://{S3_LANDING_BUCKET}/{s3_prefix}")

    for root, dirs, files in os.walk(local_data_dir):
        for filename in sorted(files):
            if not filename.endswith(".csv"):
                continue

            # Skip the combined "all" file — upload only partitioned files
            if "_all.csv" in filename:
                continue

            local_path = os.path.join(root, filename)
            stats["total_files"] += 1

            # Build S3 key preserving partition structure
            # e.g., data/positions/year=2025/month=01/day=15/positions_20250115.csv
            #    -> positions/year=2025/month=01/day=15/positions_20250115.csv
            relative_path = os.path.relpath(local_path, local_data_dir)
            s3_key = s3_prefix + relative_path.replace("\\", "/")

            # Compute metadata
            record_count = count_csv_records(local_path)
            file_md5 = calculate_md5(local_path)
            file_size = os.path.getsize(local_path)

            metadata = {
                "source": "capvault-data-generator",
                "data_type": data_type,
                "record_count": str(record_count),
                "upload_timestamp": datetime.now().isoformat(),
                "file_md5": file_md5,
            }

            success = upload_file(s3, local_path, S3_LANDING_BUCKET, s3_key, metadata)

            if success:
                stats["uploaded"] += 1
                stats["total_records"] += record_count
                stats["total_bytes"] += file_size
            else:
                stats["failed"] += 1

    return stats


def main():
    """Main upload script with CLI arguments."""
    parser = argparse.ArgumentParser(
        description="Upload CapVault sample data to S3 landing bucket."
    )
    parser.add_argument(
        "--data-type",
        choices=["positions", "transactions", "all"],
        default="all",
        help="Type of data to upload (default: all)",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="Delete existing data in the landing bucket before uploading",
    )
    args = parser.parse_args()

    print("\n[UPLOAD] CapVault - S3 Data Upload")
    print(f"   Timestamp:   {datetime.now().isoformat()}")
    print(f"   Bucket:      {S3_LANDING_BUCKET}")
    print(f"   Region:      {AWS_REGION}")
    print(f"   Data Type:   {args.data_type}")

    project_root = os.path.join(os.path.dirname(__file__), "..")
    data_dir = os.path.join(project_root, "data")

    # Clean existing data if requested
    if args.clean:
        print("\n--- Cleaning Existing Data ---")
        if args.data_type in ("positions", "all"):
            delete_prefix(S3_LANDING_BUCKET, S3_POSITIONS_PREFIX)
        if args.data_type in ("transactions", "all"):
            delete_prefix(S3_LANDING_BUCKET, S3_TRANSACTIONS_PREFIX)

    all_stats = {}

    # Upload positions
    if args.data_type in ("positions", "all"):
        print("\n--- Positions ---")
        positions_dir = os.path.join(data_dir, "positions")
        stats = upload_data_directory("positions", positions_dir, S3_POSITIONS_PREFIX)
        all_stats["positions"] = stats

    # Upload transactions
    if args.data_type in ("transactions", "all"):
        print("\n--- Transactions ---")
        transactions_dir = os.path.join(data_dir, "transactions")
        stats = upload_data_directory("transactions", transactions_dir, S3_TRANSACTIONS_PREFIX)
        all_stats["transactions"] = stats

    # Print summary
    print(f"\n{'='*60}")
    print("  Upload Summary")
    print(f"{'='*60}")

    grand_total_files = 0
    grand_total_records = 0
    grand_total_bytes = 0

    for data_type, stats in all_stats.items():
        size_mb = stats["total_bytes"] / (1024 * 1024)
        print(f"\n  {data_type.upper()}:")
        print(f"    Files uploaded:  {stats['uploaded']}/{stats['total_files']}")
        print(f"    Files failed:    {stats['failed']}")
        print(f"    Total records:   {stats['total_records']}")
        print(f"    Total size:      {size_mb:.2f} MB")
        grand_total_files += stats["uploaded"]
        grand_total_records += stats["total_records"]
        grand_total_bytes += stats["total_bytes"]

    grand_size_mb = grand_total_bytes / (1024 * 1024)
    print(f"\n  GRAND TOTAL:")
    print(f"    Files:   {grand_total_files}")
    print(f"    Records: {grand_total_records}")
    print(f"    Size:    {grand_size_mb:.2f} MB")
    print(f"{'='*60}")

    # Show bucket contents after upload
    print("\n--- Landing Bucket Contents ---")
    print_bucket_summary(S3_LANDING_BUCKET, S3_POSITIONS_PREFIX)
    print_bucket_summary(S3_LANDING_BUCKET, S3_TRANSACTIONS_PREFIX)

    print()


if __name__ == "__main__":
    main()
