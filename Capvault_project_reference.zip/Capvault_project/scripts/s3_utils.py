"""
S3 Utility Functions for CapVault Pipeline
============================================
Common operations for interacting with S3 landing and curated buckets.
"""

import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    S3_LANDING_BUCKET,
    S3_CURATED_BUCKET,
)


def get_s3_client():
    """Create and return an S3 client."""
    return boto3.client("s3", region_name=AWS_REGION)


def list_objects(bucket: str, prefix: str = "", max_keys: int = 100) -> list:
    """
    List objects in an S3 bucket under a given prefix.

    Args:
        bucket: S3 bucket name
        prefix: Key prefix to filter objects
        max_keys: Maximum number of keys to return

    Returns:
        List of dicts with 'Key', 'Size', 'LastModified' for each object.
    """
    s3 = get_s3_client()
    objects = []

    try:
        paginator = s3.get_paginator("list_objects_v2")
        page_iterator = paginator.paginate(
            Bucket=bucket,
            Prefix=prefix,
            PaginationConfig={"MaxItems": max_keys}
        )

        for page in page_iterator:
            for obj in page.get("Contents", []):
                objects.append({
                    "Key": obj["Key"],
                    "Size": obj["Size"],
                    "LastModified": obj["LastModified"].isoformat(),
                })
    except ClientError as e:
        print(f"[ERROR] Failed to list objects in s3://{bucket}/{prefix}: {e}")

    return objects


def check_prefix_exists(bucket: str, prefix: str) -> bool:
    """
    Check if any objects exist under a given S3 prefix.

    Args:
        bucket: S3 bucket name
        prefix: Key prefix to check

    Returns:
        True if at least one object exists under the prefix.
    """
    s3 = get_s3_client()
    try:
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix, MaxKeys=1)
        return response.get("KeyCount", 0) > 0
    except ClientError as e:
        print(f"[ERROR] Failed to check prefix s3://{bucket}/{prefix}: {e}")
        return False


def get_object_metadata(bucket: str, key: str) -> dict:
    """
    Get metadata for an S3 object.

    Args:
        bucket: S3 bucket name
        key: Object key

    Returns:
        Dict with ContentLength, ContentType, LastModified, and custom metadata.
    """
    s3 = get_s3_client()
    try:
        response = s3.head_object(Bucket=bucket, Key=key)
        return {
            "ContentLength": response["ContentLength"],
            "ContentType": response.get("ContentType", ""),
            "LastModified": response["LastModified"].isoformat(),
            "Metadata": response.get("Metadata", {}),
        }
    except ClientError as e:
        print(f"[ERROR] Failed to get metadata for s3://{bucket}/{key}: {e}")
        return {}


def delete_object(bucket: str, key: str) -> bool:
    """
    Delete a single object from S3.

    Args:
        bucket: S3 bucket name
        key: Object key to delete

    Returns:
        True if deletion was successful.
    """
    s3 = get_s3_client()
    try:
        s3.delete_object(Bucket=bucket, Key=key)
        print(f"  [OK] Deleted s3://{bucket}/{key}")
        return True
    except ClientError as e:
        print(f"  [FAIL] Failed to delete s3://{bucket}/{key}: {e}")
        return False


def delete_prefix(bucket: str, prefix: str) -> int:
    """
    Delete all objects under a given S3 prefix.

    Args:
        bucket: S3 bucket name
        prefix: Key prefix — all objects under this prefix will be deleted

    Returns:
        Number of objects deleted.
    """
    s3 = get_s3_client()
    deleted_count = 0

    try:
        paginator = s3.get_paginator("list_objects_v2")
        page_iterator = paginator.paginate(Bucket=bucket, Prefix=prefix)

        for page in page_iterator:
            objects = page.get("Contents", [])
            if not objects:
                continue

            delete_keys = [{"Key": obj["Key"]} for obj in objects]
            s3.delete_objects(
                Bucket=bucket,
                Delete={"Objects": delete_keys}
            )
            deleted_count += len(delete_keys)

    except ClientError as e:
        print(f"[ERROR] Failed to delete prefix s3://{bucket}/{prefix}: {e}")

    print(f"  [OK] Deleted {deleted_count} objects under s3://{bucket}/{prefix}")
    return deleted_count


def download_file(bucket: str, key: str, local_path: str) -> bool:
    """
    Download a file from S3 to a local path.

    Args:
        bucket: S3 bucket name
        key: Object key
        local_path: Local file path to save to

    Returns:
        True if download was successful.
    """
    s3 = get_s3_client()
    try:
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        s3.download_file(bucket, key, local_path)
        print(f"  [OK] Downloaded s3://{bucket}/{key} -> {local_path}")
        return True
    except ClientError as e:
        print(f"  [FAIL] Failed to download s3://{bucket}/{key}: {e}")
        return False


def print_bucket_summary(bucket: str, prefix: str = "") -> None:
    """Print a summary of objects in a bucket/prefix."""
    objects = list_objects(bucket, prefix, max_keys=1000)
    total_size = sum(obj["Size"] for obj in objects)
    size_mb = total_size / (1024 * 1024)

    print(f"\n  Bucket:  s3://{bucket}/{prefix}")
    print(f"  Objects: {len(objects)}")
    print(f"  Size:    {size_mb:.2f} MB")

    if objects:
        print(f"  Latest:  {objects[-1]['Key']}")


# ---------------------------------------------------------------------------
# Main — CLI utility
# ---------------------------------------------------------------------------

def main():
    """CLI utility to list bucket contents."""
    print("\n[INFO] CapVault - S3 Utility")
    print(f"   Region: {AWS_REGION}")

    print("\n--- Landing Bucket ---")
    print_bucket_summary(S3_LANDING_BUCKET)

    print("\n--- Curated Bucket ---")
    print_bucket_summary(S3_CURATED_BUCKET)


if __name__ == "__main__":
    main()
