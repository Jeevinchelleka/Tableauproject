"""
Glue Job Monitoring Script -- CapVault Pipeline
=================================================
Checks and displays the execution history, performance metrics, and logs
for CapVault Glue ETL jobs.

Usage:
    python scripts/monitor_jobs.py
    python scripts/monitor_jobs.py --job-name capvault-positions-etl
    python scripts/monitor_jobs.py --limit 5
"""

import sys
import os
import argparse
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    GLUE_JOB_POSITIONS_ETL,
    GLUE_JOB_TRANSACTIONS_ETL,
)


def get_glue_client():
    """Create and return a Glue client."""
    return boto3.client("glue", region_name=AWS_REGION)


def print_job_info(glue_client, job_name: str) -> None:
    """Print Glue Job definition properties."""
    try:
        response = glue_client.get_job(JobName=job_name)
        job = response.get("Job", {})
        print(f"\nJob Definition: {job_name}")
        print(f"  Role:           {job.get('Role', '')}")
        print(f"  Glue Version:   {job.get('GlueVersion', '')}")
        print(f"  Worker Type:    {job.get('WorkerType', '')}")
        print(f"  Workers:        {job.get('NumberOfWorkers', 0)}")
        print(f"  Max Capacity:   {job.get('MaxCapacity', 0.0)} DPUs")
        print(f"  Timeout:        {job.get('Timeout', 0)} mins")
    except ClientError as e:
        print(f"  [FAIL] Failed to retrieve definition for job '{job_name}': {e}")


def list_job_runs(glue_client, job_name: str, limit: int = 5) -> None:
    """List execution history details of a Glue job."""
    print(f"\nExecution History for '{job_name}' (Last {limit} runs):")
    try:
        response = glue_client.get_job_runs(JobName=job_name, MaxResults=limit)
        runs = response.get("JobRuns", [])

        if not runs:
            print("  No runs found for this job.")
            return

        print(f"  {'Run ID':<40} | {'Status':<12} | {'Started At':<20} | {'Duration (s)':<12} | {'DPU Seconds':<12}")
        print(f"  {'-'*40}-|-{'-'*12}-|-{'-'*20}-|-{'-'*12}-|-{'-'*12}")

        for run in runs:
            run_id = run.get("Id", "")
            state = run.get("JobRunState", "UNKNOWN")
            started_on = run.get("StartedOn")
            started_str = started_on.strftime("%Y-%m-%d %H:%M:%S") if started_on else "UNKNOWN"
            duration = run.get("ExecutionTime", 0)
            
            # Max capacity in DPUs * Execution time in seconds
            dpu_sec = run.get("DPUSeconds", 0.0)

            print(f"  {run_id:<40} | {state:<12} | {started_str:<20} | {duration:<12} | {dpu_sec:<12.1f}")

            # Print error messages if the run failed
            if state == "FAILED" and "ErrorMessage" in run:
                print(f"    [ERROR MESSAGE] {run['ErrorMessage']}")
            
    except ClientError as e:
        print(f"  [FAIL] Failed to list runs for job '{job_name}': {e}")


def main():
    parser = argparse.ArgumentParser(description="Monitor CapVault Glue Job runs.")
    parser.add_argument(
        "--job-name",
        choices=[GLUE_JOB_POSITIONS_ETL, GLUE_JOB_TRANSACTIONS_ETL, "all"],
        default="all",
        help="Glue job name to monitor (default: all)",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=5,
        help="Number of past execution runs to display (default: 5)",
    )
    args = parser.parse_args()

    print("\n[MONITOR] CapVault - Glue Job Performance Monitoring")
    print(f"   Region:    {AWS_REGION}")
    print(f"   Timestamp: {datetime.now().isoformat()}")

    glue = get_glue_client()

    jobs_to_check = []
    if args.job_name == "all":
        jobs_to_check = [GLUE_JOB_POSITIONS_ETL, GLUE_JOB_TRANSACTIONS_ETL]
    else:
        jobs_to_check = [args.job_name]

    for job_name in jobs_to_check:
        print(f"\n============================================================")
        print_job_info(glue, job_name)
        list_job_runs(glue, job_name, args.limit)
    
    print("\n============================================================\n")


if __name__ == "__main__":
    main()
