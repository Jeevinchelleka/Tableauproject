"""
Sample Data Generator for CapVault Pipeline
=============================================
Generates realistic financial data for positions and transactions.
Intentionally introduces ~15% bad records for data quality testing.

Usage:
    python scripts/generate_sample_data.py
"""

import sys
import os
import random
import csv
import uuid
from datetime import datetime, timedelta

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config.aws_config import (
    VALID_CURRENCIES,
    VALID_TRANSACTION_TYPES,
    VALID_ASSET_CLASSES,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
NUM_POSITIONS = 1000
NUM_TRANSACTIONS = 2000
BAD_RECORD_RATIO = 0.15  # 15% intentionally bad records

# Reference data for realistic generation
SECURITIES = [
    ("AAPL", "Apple Inc."),
    ("MSFT", "Microsoft Corp."),
    ("GOOGL", "Alphabet Inc."),
    ("AMZN", "Amazon.com Inc."),
    ("TSLA", "Tesla Inc."),
    ("META", "Meta Platforms Inc."),
    ("NVDA", "NVIDIA Corp."),
    ("JPM", "JPMorgan Chase & Co."),
    ("V", "Visa Inc."),
    ("JNJ", "Johnson & Johnson"),
    ("WMT", "Walmart Inc."),
    ("PG", "Procter & Gamble Co."),
    ("UNH", "UnitedHealth Group Inc."),
    ("HD", "Home Depot Inc."),
    ("MA", "Mastercard Inc."),
    ("DIS", "Walt Disney Co."),
    ("NFLX", "Netflix Inc."),
    ("ADBE", "Adobe Inc."),
    ("CRM", "Salesforce Inc."),
    ("INTC", "Intel Corp."),
    ("RELIANCE", "Reliance Industries Ltd."),
    ("TCS", "Tata Consultancy Services"),
    ("INFY", "Infosys Ltd."),
    ("HDFCBANK", "HDFC Bank Ltd."),
    ("ICICIBANK", "ICICI Bank Ltd."),
]

CUSTODIANS = [
    "Goldman Sachs", "Morgan Stanley", "JP Morgan",
    "BNY Mellon", "State Street", "Northern Trust",
    "Citi", "Deutsche Bank",
]

BROKERS = [
    "Goldman Sachs", "Morgan Stanley", "Merrill Lynch",
    "Charles Schwab", "Fidelity", "Interactive Brokers",
    "TD Ameritrade", "E*TRADE", "Zerodha", "ICICI Direct",
]

ACCOUNT_IDS = [f"ACC-{str(i).zfill(5)}" for i in range(1, 51)]
PORTFOLIO_IDS = [f"PF-{str(i).zfill(4)}" for i in range(1, 21)]


def random_date(start_days_ago: int = 180, end_days_ago: int = 1) -> str:
    """Generate a random date string between start_days_ago and end_days_ago."""
    start = datetime.now() - timedelta(days=start_days_ago)
    end = datetime.now() - timedelta(days=end_days_ago)
    delta = end - start
    random_day = start + timedelta(days=random.randint(0, delta.days))
    return random_day.strftime("%Y-%m-%d")


def future_date() -> str:
    """Generate a date in the future (intentionally bad)."""
    future = datetime.now() + timedelta(days=random.randint(30, 365))
    return future.strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Position Data Generation
# ---------------------------------------------------------------------------

def generate_good_position(idx: int) -> dict:
    """Generate a valid position record."""
    security = random.choice(SECURITIES)
    quantity = round(random.uniform(10, 10000), 2)
    price = round(random.uniform(5.0, 3500.0), 2)
    market_value = round(quantity * price, 2)
    cost_basis = round(market_value * random.uniform(0.7, 1.3), 2)

    return {
        "position_id": f"POS-{str(idx).zfill(7)}",
        "account_id": random.choice(ACCOUNT_IDS),
        "security_id": security[0],
        "security_name": security[1],
        "quantity": quantity,
        "market_value": market_value,
        "cost_basis": cost_basis,
        "currency": random.choice(VALID_CURRENCIES),
        "asset_class": random.choice(VALID_ASSET_CLASSES),
        "position_date": random_date(),
        "custodian": random.choice(CUSTODIANS),
        "portfolio_id": random.choice(PORTFOLIO_IDS),
    }


def generate_bad_position(idx: int) -> dict:
    """Generate an intentionally invalid position record for DQ testing."""
    record = generate_good_position(idx)

    # Randomly introduce one or more defects
    defect_type = random.choice([
        "null_account",
        "null_security",
        "negative_quantity",
        "future_date",
        "invalid_currency",
        "empty_name",
        "null_position_id",
        "negative_market_value",
    ])

    if defect_type == "null_account":
        record["account_id"] = ""
    elif defect_type == "null_security":
        record["security_id"] = ""
    elif defect_type == "negative_quantity":
        record["quantity"] = round(random.uniform(-1000, -1), 2)
    elif defect_type == "future_date":
        record["position_date"] = future_date()
    elif defect_type == "invalid_currency":
        record["currency"] = random.choice(["XYZ", "ABC", "999", "", "INVALID"])
    elif defect_type == "empty_name":
        record["security_name"] = ""
    elif defect_type == "null_position_id":
        record["position_id"] = ""
    elif defect_type == "negative_market_value":
        record["market_value"] = round(random.uniform(-50000, -1), 2)

    return record


def generate_positions(num_records: int) -> list:
    """Generate a mix of good and bad position records."""
    records = []
    num_bad = int(num_records * BAD_RECORD_RATIO)
    num_good = num_records - num_bad

    print(f"  Generating {num_good} good + {num_bad} bad position records...")

    for i in range(1, num_good + 1):
        records.append(generate_good_position(i))

    for i in range(num_good + 1, num_records + 1):
        records.append(generate_bad_position(i))

    # Shuffle so bad records are mixed in
    random.shuffle(records)
    return records


# ---------------------------------------------------------------------------
# Transaction Data Generation
# ---------------------------------------------------------------------------

def generate_good_transaction(idx: int) -> dict:
    """Generate a valid transaction record."""
    security = random.choice(SECURITIES)
    txn_type = random.choice(VALID_TRANSACTION_TYPES)
    quantity = round(random.uniform(1, 5000), 2)
    price = round(random.uniform(5.0, 3500.0), 4)

    if txn_type == "DIVIDEND":
        quantity = round(random.uniform(1, 500), 2)
        price = round(random.uniform(0.5, 10.0), 4)

    amount = round(quantity * price, 2)
    trade_date = random_date()
    # Settlement is T+2 to T+5
    trade_dt = datetime.strptime(trade_date, "%Y-%m-%d")
    settlement_dt = trade_dt + timedelta(days=random.randint(2, 5))
    settlement_date = settlement_dt.strftime("%Y-%m-%d")

    return {
        "transaction_id": f"TXN-{str(idx).zfill(8)}",
        "account_id": random.choice(ACCOUNT_IDS),
        "security_id": security[0],
        "security_name": security[1],
        "transaction_type": txn_type,
        "quantity": quantity,
        "price": price,
        "amount": amount,
        "currency": random.choice(VALID_CURRENCIES),
        "trade_date": trade_date,
        "settlement_date": settlement_date,
        "broker": random.choice(BROKERS),
        "portfolio_id": random.choice(PORTFOLIO_IDS),
    }


def generate_bad_transaction(idx: int) -> dict:
    """Generate an intentionally invalid transaction record for DQ testing."""
    record = generate_good_transaction(idx)

    defect_type = random.choice([
        "null_account",
        "null_security",
        "null_transaction_id",
        "invalid_type",
        "negative_quantity",
        "negative_price",
        "invalid_currency",
        "future_trade_date",
        "settlement_before_trade",
    ])

    if defect_type == "null_account":
        record["account_id"] = ""
    elif defect_type == "null_security":
        record["security_id"] = ""
    elif defect_type == "null_transaction_id":
        record["transaction_id"] = ""
    elif defect_type == "invalid_type":
        record["transaction_type"] = random.choice(["PURCHASE", "SALE", "INVALID", "", "X"])
    elif defect_type == "negative_quantity":
        record["quantity"] = round(random.uniform(-5000, -1), 2)
    elif defect_type == "negative_price":
        record["price"] = round(random.uniform(-100, -0.01), 4)
    elif defect_type == "invalid_currency":
        record["currency"] = random.choice(["XYZ", "ABC", "999", "", "INVALID"])
    elif defect_type == "future_trade_date":
        record["trade_date"] = future_date()
        # Settlement also in future
        trade_dt = datetime.strptime(record["trade_date"], "%Y-%m-%d")
        record["settlement_date"] = (trade_dt + timedelta(days=3)).strftime("%Y-%m-%d")
    elif defect_type == "settlement_before_trade":
        # Make settlement date BEFORE trade date
        trade_dt = datetime.strptime(record["trade_date"], "%Y-%m-%d")
        record["settlement_date"] = (trade_dt - timedelta(days=random.randint(1, 10))).strftime("%Y-%m-%d")

    return record


def generate_transactions(num_records: int) -> list:
    """Generate a mix of good and bad transaction records."""
    records = []
    num_bad = int(num_records * BAD_RECORD_RATIO)
    num_good = num_records - num_bad

    print(f"  Generating {num_good} good + {num_bad} bad transaction records...")

    for i in range(1, num_good + 1):
        records.append(generate_good_transaction(i))

    for i in range(num_good + 1, num_records + 1):
        records.append(generate_bad_transaction(i))

    # Shuffle so bad records are mixed in
    random.shuffle(records)
    return records


# ---------------------------------------------------------------------------
# File Writing
# ---------------------------------------------------------------------------

def write_csv(records: list, filepath: str) -> None:
    """Write records to a CSV file."""
    if not records:
        print(f"  [WARN] No records to write to {filepath}")
        return

    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    fieldnames = list(records[0].keys())
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)

    print(f"  [OK] Written {len(records)} records to {filepath}")


def split_by_date(records: list, date_field: str) -> dict:
    """Split records by date for partitioned file output."""
    date_groups = {}
    for record in records:
        date_val = record.get(date_field, "unknown")
        if date_val not in date_groups:
            date_groups[date_val] = []
        date_groups[date_val].append(record)
    return date_groups


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    """Generate sample data and write to CSV files."""
    print("\n[BUILD] CapVault - Sample Data Generator")
    print(f"   Timestamp: {datetime.now().isoformat()}")
    print(f"   Positions: {NUM_POSITIONS} records ({int(BAD_RECORD_RATIO*100)}% bad)")
    print(f"   Transactions: {NUM_TRANSACTIONS} records ({int(BAD_RECORD_RATIO*100)}% bad)")

    project_root = os.path.join(os.path.dirname(__file__), "..")
    data_dir = os.path.join(project_root, "data")

    # --- Generate Positions ---
    print(f"\n[POSITIONS] Generating Position Data...")
    positions = generate_positions(NUM_POSITIONS)
    position_groups = split_by_date(positions, "position_date")

    positions_dir = os.path.join(data_dir, "positions")
    for date_str, date_records in position_groups.items():
        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            partition_dir = os.path.join(
                positions_dir,
                f"year={dt.year}",
                f"month={str(dt.month).zfill(2)}",
                f"day={str(dt.day).zfill(2)}"
            )
            filename = f"positions_{date_str.replace('-', '')}.csv"
        except ValueError:
            partition_dir = os.path.join(positions_dir, "unknown")
            filename = f"positions_unknown_{uuid.uuid4().hex[:8]}.csv"

        write_csv(date_records, os.path.join(partition_dir, filename))

    # Also write a single combined file for convenience
    combined_positions_path = os.path.join(positions_dir, "positions_all.csv")
    write_csv(positions, combined_positions_path)

    # --- Generate Transactions ---
    print(f"\n[TRANSACTIONS] Generating Transaction Data...")
    transactions = generate_transactions(NUM_TRANSACTIONS)
    transaction_groups = split_by_date(transactions, "trade_date")

    transactions_dir = os.path.join(data_dir, "transactions")
    for date_str, date_records in transaction_groups.items():
        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            partition_dir = os.path.join(
                transactions_dir,
                f"year={dt.year}",
                f"month={str(dt.month).zfill(2)}",
                f"day={str(dt.day).zfill(2)}"
            )
            filename = f"transactions_{date_str.replace('-', '')}.csv"
        except ValueError:
            partition_dir = os.path.join(transactions_dir, "unknown")
            filename = f"transactions_unknown_{uuid.uuid4().hex[:8]}.csv"

        write_csv(date_records, os.path.join(partition_dir, filename))

    # Also write a single combined file
    combined_txn_path = os.path.join(transactions_dir, "transactions_all.csv")
    write_csv(transactions, combined_txn_path)

    # --- Summary ---
    print(f"\n{'='*60}")
    print(f"  [OK] Data generation complete!")
    print(f"     Positions:    {len(positions)} records across {len(position_groups)} dates")
    print(f"     Transactions: {len(transactions)} records across {len(transaction_groups)} dates")
    print(f"     Output dir:   {os.path.abspath(data_dir)}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
