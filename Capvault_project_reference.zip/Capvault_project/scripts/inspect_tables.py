"""
Inspect Glue Tables Metadata
==============================
Inspects the Glue Catalog table definitions to see if they are configured
properly for Apache Iceberg.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    GLUE_DATABASE,
    GLUE_TABLE_POSITION_GOOD,
    GLUE_TABLE_POSITION_BAD,
    GLUE_TABLE_TRANSACTION_GOOD,
    GLUE_TABLE_TRANSACTION_BAD,
)


def main():
    print(f"\n[INSPECT] Checking Glue Catalog Tables in '{GLUE_DATABASE}'...")
    glue = boto3.client("glue", region_name=AWS_REGION)

    tables = [
        GLUE_TABLE_POSITION_GOOD,
        GLUE_TABLE_POSITION_BAD,
        GLUE_TABLE_TRANSACTION_GOOD,
        GLUE_TABLE_TRANSACTION_BAD,
    ]

    for table_name in tables:
        print(f"\nTable: {table_name}")
        print("-" * 40)
        try:
            response = glue.get_table(DatabaseName=GLUE_DATABASE, Name=table_name)
            table = response.get("Table", {})
            
            # Print table parameters & details
            parameters = table.get("Parameters", {})
            table_type = parameters.get("table_type", "Standard/Hive (Not Iceberg)")
            
            print(f"  Table Type:  {table_type}")
            print(f"  Location:    {table.get('StorageDescriptor', {}).get('Location', 'N/A')}")
            print(f"  Parameters:")
            for k, v in parameters.items():
                if k in ["table_type", "classification", "metadata_location"]:
                    print(f"    {k}: {v}")
                    
        except ClientError as e:
            if e.response["Error"]["Code"] == "EntityNotFoundException":
                print("  [NOT FOUND] Table does not exist in Glue Catalog.")
            else:
                print(f"  [ERROR] {e}")


if __name__ == "__main__":
    main()
