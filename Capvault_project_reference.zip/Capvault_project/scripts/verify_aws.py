"""
AWS Connectivity Verification Script
======================================
Verifies that all required AWS resources are accessible:
  - S3 buckets (landing & curated)
  - Glue database & tables
  - Aurora RDS cluster
"""

import sys
import os
import json
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from config.aws_config import (
    AWS_REGION,
    S3_LANDING_BUCKET,
    S3_CURATED_BUCKET,
    GLUE_DATABASE,
    GLUE_TABLE_POSITION_GOOD,
    GLUE_TABLE_POSITION_BAD,
    GLUE_TABLE_TRANSACTION_GOOD,
    GLUE_TABLE_TRANSACTION_BAD,
    RDS_CLUSTER_IDENTIFIER,
    RDS_HOST,
    RDS_PORT,
    RDS_DATABASE_NAME,
    RDS_USER,
    get_cached_rds_password,
)


def print_header(title: str) -> None:
    """Print a formatted section header."""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def print_result(check: str, passed: bool, detail: str = "") -> None:
    """Print a check result with pass/fail indicator."""
    icon = "[PASS]" if passed else "[FAIL]"
    msg = f"  {icon} {check}"
    if detail:
        msg += f" - {detail}"
    print(msg)


def verify_s3(session: boto3.Session) -> list:
    """Verify S3 buckets exist and are accessible."""
    print_header("S3 Buckets")
    s3 = session.client("s3", region_name=AWS_REGION)
    results = []

    for bucket_name in [S3_LANDING_BUCKET, S3_CURATED_BUCKET]:
        try:
            s3.head_bucket(Bucket=bucket_name)
            # List objects to check read access
            response = s3.list_objects_v2(Bucket=bucket_name, MaxKeys=5)
            obj_count = response.get("KeyCount", 0)
            print_result(
                f"Bucket '{bucket_name}'",
                True,
                f"accessible ({obj_count} objects found)"
            )
            results.append(True)
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "404":
                print_result(f"Bucket '{bucket_name}'", False, "does NOT exist")
            elif error_code == "403":
                print_result(f"Bucket '{bucket_name}'", False, "access DENIED")
            else:
                print_result(f"Bucket '{bucket_name}'", False, str(e))
            results.append(False)

    return results


def verify_glue(session: boto3.Session) -> list:
    """Verify Glue database and tables exist."""
    print_header("AWS Glue")
    glue = session.client("glue", region_name=AWS_REGION)
    results = []

    # Check database
    try:
        glue.get_database(Name=GLUE_DATABASE)
        print_result(f"Database '{GLUE_DATABASE}'", True, "exists")
        results.append(True)
    except ClientError as e:
        print_result(f"Database '{GLUE_DATABASE}'", False, str(e))
        results.append(False)
        return results  # No point checking tables if DB doesn't exist

    # Check tables
    expected_tables = [
        GLUE_TABLE_POSITION_GOOD,
        GLUE_TABLE_POSITION_BAD,
        GLUE_TABLE_TRANSACTION_GOOD,
        GLUE_TABLE_TRANSACTION_BAD,
    ]

    for table_name in expected_tables:
        try:
            response = glue.get_table(DatabaseName=GLUE_DATABASE, Name=table_name)
            table_info = response.get("Table", {})
            table_type = table_info.get("Parameters", {}).get("table_type", "unknown")
            print_result(
                f"Table '{table_name}'",
                True,
                f"exists (type: {table_type})"
            )
            results.append(True)
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "EntityNotFoundException":
                print_result(f"Table '{table_name}'", False, "does NOT exist")
            else:
                print_result(f"Table '{table_name}'", False, str(e))
            results.append(False)

    return results


def verify_rds(session: boto3.Session) -> list:
    """Verify Aurora RDS cluster exists and check active DB connectivity."""
    print_header("Aurora / RDS")
    rds = session.client("rds", region_name=AWS_REGION)
    results = []

    try:
        response = rds.describe_db_clusters(
            DBClusterIdentifier=RDS_CLUSTER_IDENTIFIER
        )
        clusters = response.get("DBClusters", [])
        if clusters:
            cluster = clusters[0]
            status = cluster.get("Status", "unknown")
            engine = cluster.get("Engine", "unknown")
            print_result(
                f"RDS Cluster '{RDS_CLUSTER_IDENTIFIER}'",
                True,
                f"status={status}, engine={engine}"
            )
            results.append(True)
        else:
            print_result(
                f"RDS Cluster '{RDS_CLUSTER_IDENTIFIER}'", False, "not found"
            )
            results.append(False)
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code == "DBClusterNotFoundFault":
            # Try as a DB instance instead
            try:
                response = rds.describe_db_instances(
                    DBInstanceIdentifier=RDS_CLUSTER_IDENTIFIER
                )
                instances = response.get("DBInstances", [])
                if instances:
                    inst = instances[0]
                    status = inst.get("DBInstanceStatus", "unknown")
                    engine = inst.get("Engine", "unknown")
                    print_result(
                        f"RDS Instance '{RDS_CLUSTER_IDENTIFIER}'",
                        True,
                        f"status={status}, engine={engine}"
                    )
                    results.append(True)
                else:
                    print_result(
                        f"RDS '{RDS_CLUSTER_IDENTIFIER}'", False, "not found"
                    )
                    results.append(False)
            except ClientError as e2:
                print_result(
                    f"RDS '{RDS_CLUSTER_IDENTIFIER}'", False, str(e2)
                )
                results.append(False)
        else:
            print_result(
                f"RDS Cluster '{RDS_CLUSTER_IDENTIFIER}'", False, str(e)
            )
            results.append(False)

    # 2. Live DB Connection Check
    try:
        import psycopg2

        try:
            rds_password = get_cached_rds_password()
        except RuntimeError as e:
            print_result("RDS Connection Check", False, f"Could not resolve RDS password: {e}")
            results.append(False)
            return results

        conn = psycopg2.connect(
            host=RDS_HOST,
            port=RDS_PORT,
            database=RDS_DATABASE_NAME,
            user=RDS_USER,
            password=rds_password,
            sslmode="require",
            connect_timeout=5
        )
        print_result(
            "RDS Connection Check",
            True,
            f"Connected successfully to db '{RDS_DATABASE_NAME}' as user '{RDS_USER}'"
        )
        conn.close()
        results.append(True)
    except Exception as e:
        print_result("RDS Connection Check", False, f"Failed to connect: {e}")
        results.append(False)

    return results


def verify_caller_identity(session: boto3.Session) -> bool:
    """Verify AWS credentials and show caller identity."""
    print_header("AWS Caller Identity")
    sts = session.client("sts", region_name=AWS_REGION)

    try:
        identity = sts.get_caller_identity()
        print_result("AWS Credentials", True, "valid")
        print(f"      Account:  {identity['Account']}")
        print(f"      ARN:      {identity['Arn']}")
        print(f"      User ID:  {identity['UserId']}")
        return True
    except (ClientError, NoCredentialsError) as e:
        print_result("AWS Credentials", False, str(e))
        return False


def main():
    """Run all AWS connectivity verification checks."""
    print(f"\n[CHECK] CapVault - AWS Connectivity Verification")
    print(f"   Timestamp: {datetime.now().isoformat()}")
    print(f"   Region:    {AWS_REGION}")

    session = boto3.Session(region_name=AWS_REGION)

    all_results = []

    # 1. Verify credentials
    cred_ok = verify_caller_identity(session)
    all_results.append(cred_ok)

    if not cred_ok:
        print("\n[FAIL] Cannot proceed without valid AWS credentials.")
        print("   Configure credentials via:")
        print("     - AWS CLI: aws configure")
        print("     - Environment: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY")
        print("     - AWS credentials file: ~/.aws/credentials")
        sys.exit(1)

    # 2. Verify S3
    all_results.extend(verify_s3(session))

    # 3. Verify Glue
    all_results.extend(verify_glue(session))

    # 4. Verify RDS
    all_results.extend(verify_rds(session))

    # Summary
    print_header("Summary")
    passed = sum(1 for r in all_results if r)
    total = len(all_results)
    print(f"  {passed}/{total} checks passed")

    if all(all_results):
        print("\n  [OK] All AWS resources verified successfully!\n")
    else:
        print("\n  [WARN] Some checks failed. Review the output above.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()