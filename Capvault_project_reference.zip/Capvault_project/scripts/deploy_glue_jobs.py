"""
Glue Job Deployment Script for CapVault Pipeline
==================================================
Uploads Glue ETL job scripts (positions_etl.py, transactions_etl.py,
data_quality.py, job_config.py) to S3, and creates/updates the
AWS Glue Job definitions via boto3.

Usage:
    python scripts/deploy_glue_jobs.py
"""

import sys
import os
import zipfile
import tempfile

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    S3_LANDING_BUCKET,
    S3_CURATED_BUCKET,
    S3_GLUE_SCRIPTS_PREFIX,
    S3_ICEBERG_WAREHOUSE,
    GLUE_DATABASE,
    GLUE_JOB_POSITIONS_ETL,
    GLUE_JOB_TRANSACTIONS_ETL,
    GLUE_IAM_ROLE,
    GLUE_WORKER_TYPE,
    GLUE_NUM_WORKERS,
    GLUE_TIMEOUT_MINUTES,
    GLUE_VERSION,
)


def get_glue_client():
    """Create and return a Glue client."""
    return boto3.client("glue", region_name=AWS_REGION)


def get_s3_client():
    """Create and return an S3 client."""
    return boto3.client("s3", region_name=AWS_REGION)


def upload_script_to_s3(local_path: str, s3_key: str) -> bool:
    """Upload a script file to S3 curated bucket where Glue can read it."""
    s3 = get_s3_client()
    try:
        s3.upload_file(
            Filename=local_path,
            Bucket=S3_CURATED_BUCKET,
            Key=s3_key
        )
        print(f"  [OK] Uploaded: {local_path} -> s3://{S3_CURATED_BUCKET}/{s3_key}")
        return True
    except ClientError as e:
        print(f"  [FAIL] Failed to upload {local_path}: {e}")
        return False


def zip_and_upload_package(local_dir: str, s3_key: str) -> bool:
    """
    Zip a Python package directory and upload to S3.
    Used to package config/ so Glue can import it via --extra-py-files.
    """
    s3 = get_s3_client()
    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            zip_path = tmp.name

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(local_dir):
                # Skip __pycache__ directories
                dirs[:] = [d for d in dirs if d != "__pycache__"]
                for file in files:
                    if file.endswith(".pyc"):
                        continue
                    abs_path = os.path.join(root, file)
                    arc_name = os.path.relpath(abs_path, os.path.dirname(local_dir))
                    zf.write(abs_path, arc_name)

        s3.upload_file(
            Filename=zip_path,
            Bucket=S3_CURATED_BUCKET,
            Key=s3_key
        )
        os.unlink(zip_path)
        print(f"  [OK] Zipped and uploaded: {local_dir}/ -> s3://{S3_CURATED_BUCKET}/{s3_key}")
        return True
    except Exception as e:
        print(f"  [FAIL] Failed to zip/upload {local_dir}: {e}")
        return False


def create_or_update_glue_job(
    glue_client,
    job_name: str,
    script_s3_key: str,
    extra_files_s3_keys: list = None
) -> bool:
    """
    Create a new Glue job or update it if it already exists.
    """
    script_location = f"s3://{S3_CURATED_BUCKET}/{script_s3_key}"

    # Build --extra-py-files: shared modules + config package
    # These must be in S3 so Glue can distribute them to all workers.
    extra_py_files = []
    if extra_files_s3_keys:
        extra_py_files = [
            f"s3://{S3_CURATED_BUCKET}/{key}" for key in extra_files_s3_keys
        ]

    # Default arguments for Glue Job
    default_arguments = {
        "--job-language": "python",
        "--DATABASE": GLUE_DATABASE,
        "--LANDING_BUCKET": S3_LANDING_BUCKET,
        "--CURATED_BUCKET": S3_CURATED_BUCKET,
        "--WAREHOUSE_PATH": S3_ICEBERG_WAREHOUSE,
        "--enable-metrics": "true",
        "--enable-continuous-cloudwatch-log": "true",
        "--continuous-log-logGroup": "/aws-glue/jobs/capvault",
        "--enable-spark-ui": "true",
        "--spark-event-logs-path": f"s3://{S3_CURATED_BUCKET}/spark-ui-logs/",
        "--extra-jars": "s3://my-glue-dependencies/postgresql-42.7.1.jar",
        "--additional-python-modules": "psycopg2-binary",
    }

    # Wire shared Python modules so Glue workers can import them
    if extra_py_files:
        default_arguments["--extra-py-files"] = ",".join(extra_py_files)

    # NOTE: RDS password is intentionally NOT passed as a job argument.
    # It is retrieved at runtime from AWS Secrets Manager by aws_config.get_cached_rds_password().

    job_command = {
        "Name": "glueetl",
        "ScriptLocation": script_location,
        "PythonVersion": "3"
    }

    try:
        # Check if job exists
        glue_client.get_job(JobName=job_name)
        job_exists = True
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityNotFoundException":
            job_exists = False
        else:
            raise e

    try:
        if job_exists:
            print(f"  [INFO] Glue Job '{job_name}' exists. Updating it...")
            glue_client.update_job(
                JobName=job_name,
                JobUpdate={
                    "Role": GLUE_IAM_ROLE,
                    "ExecutionProperty": {"MaxConcurrentRuns": 1},
                    "Command": job_command,
                    "DefaultArguments": default_arguments,
                    "MaxRetries": 0,
                    "Timeout": GLUE_TIMEOUT_MINUTES,
                    "GlueVersion": GLUE_VERSION,
                    "NumberOfWorkers": GLUE_NUM_WORKERS,
                    "WorkerType": GLUE_WORKER_TYPE
                }
            )
            print(f"  [OK] Updated Glue Job: {job_name}")
        else:
            print(f"  [INFO] Glue Job '{job_name}' does not exist. Creating it...")
            glue_client.create_job(
                Name=job_name,
                Role=GLUE_IAM_ROLE,
                ExecutionProperty={"MaxConcurrentRuns": 1},
                Command=job_command,
                DefaultArguments=default_arguments,
                MaxRetries=0,
                Timeout=GLUE_TIMEOUT_MINUTES,
                GlueVersion=GLUE_VERSION,
                NumberOfWorkers=GLUE_NUM_WORKERS,
                WorkerType=GLUE_WORKER_TYPE
            )
            print(f"  [OK] Created Glue Job: {job_name}")
        return True
    except ClientError as e:
        print(f"  [FAIL] Error deploying job {job_name}: {e}")
        return False


def main():
    print("\n[DEPLOY] CapVault - Deploying Glue Jobs to AWS")
    print(f"   Region:   {AWS_REGION}")
    print(f"   Bucket:   {S3_CURATED_BUCKET}")

    glue = get_glue_client()

    # Paths to files
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    glue_dir = os.path.join(project_root, "glue_jobs")
    config_dir = os.path.join(project_root, "config")

    pos_script = os.path.join(glue_dir, "positions_etl.py")
    txn_script = os.path.join(glue_dir, "transactions_etl.py")
    dq_module = os.path.join(glue_dir, "data_quality.py")
    config_module = os.path.join(glue_dir, "job_config.py")

    # Destination keys in S3
    pos_s3_key = f"{S3_GLUE_SCRIPTS_PREFIX}positions_etl.py"
    txn_s3_key = f"{S3_GLUE_SCRIPTS_PREFIX}transactions_etl.py"
    dq_s3_key = f"{S3_GLUE_SCRIPTS_PREFIX}data_quality.py"
    config_module_s3_key = f"{S3_GLUE_SCRIPTS_PREFIX}job_config.py"
    config_pkg_s3_key = f"{S3_GLUE_SCRIPTS_PREFIX}config.zip"  # config/ package as zip

    # Upload ETL scripts
    print("\nUploading ETL scripts to S3...")
    success = upload_script_to_s3(pos_script, pos_s3_key)
    success = upload_script_to_s3(txn_script, txn_s3_key) & success

    # Upload shared modules
    print("\nUploading shared modules to S3...")
    success = upload_script_to_s3(dq_module, dq_s3_key) & success
    success = upload_script_to_s3(config_module, config_module_s3_key) & success

    # Zip and upload config/ package (needed for 'from config.aws_config import ...')
    print("\nZipping and uploading config/ package to S3...")
    success = zip_and_upload_package(config_dir, config_pkg_s3_key) & success

    if not success:
        print("\n[FAIL] Failed to upload all scripts to S3. Aborting deployment.")
        sys.exit(1)

    # Shared extra-py-files for both jobs: data_quality, job_config, config package
    extra_py_keys = [dq_s3_key, config_module_s3_key, config_pkg_s3_key]

    # Deploy Glue Job 1: Positions ETL
    print("\nDeploying Positions ETL Glue Job...")
    pos_deployed = create_or_update_glue_job(
        glue_client=glue,
        job_name=GLUE_JOB_POSITIONS_ETL,
        script_s3_key=pos_s3_key,
        extra_files_s3_keys=extra_py_keys
    )

    # Deploy Glue Job 2: Transactions ETL
    print("\nDeploying Transactions ETL Glue Job...")
    txn_deployed = create_or_update_glue_job(
        glue_client=glue,
        job_name=GLUE_JOB_TRANSACTIONS_ETL,
        script_s3_key=txn_s3_key,
        extra_files_s3_keys=extra_py_keys
    )

    if pos_deployed and txn_deployed:
        print("\n[OK] All Glue Jobs deployed successfully!")
    else:
        print("\n[WARN] One or more Glue Jobs failed to deploy.")
        sys.exit(1)


if __name__ == "__main__":
    main()
