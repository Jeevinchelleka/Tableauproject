"""
End-to-End Pipeline Execution Script -- CapVault Pipeline
============================================================
Triggers the entire data pipeline flow from raw files to curated Iceberg tables.

Steps:
  1. Generate sample positions & transactions data (via generate_sample_data.py)
  2. Upload sample data files to S3 landing bucket (via s3_upload.py)
  3. Deploy/Update the Glue jobs in AWS (via deploy_glue_jobs.py)
  4. Trigger Positions ETL Glue Job
  5. Trigger Transactions ETL Glue Job
  6. Monitor the running Glue jobs and wait for completion
  7. Print status summary

Usage:
    python scripts/run_pipeline.py
    python scripts/run_pipeline.py --skip-gen  (skip data generation)
    python scripts/run_pipeline.py --skip-upload (skip data generation and upload)
"""

import sys
import os
import time
import argparse
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    GLUE_JOB_POSITIONS_ETL,
    GLUE_JOB_TRANSACTIONS_ETL,
)
import scripts.generate_sample_data as gen_data
import scripts.s3_upload as s3_upload
import scripts.deploy_glue_jobs as deploy_jobs


def run_command_module(module, func_name="main", *args):
    """Run a main function from a module programmatically."""
    func = getattr(module, func_name)
    # Save original sys.argv and override if needed
    orig_argv = sys.argv
    sys.argv = [module.__file__] + list(args)
    try:
        func()
    finally:
        sys.argv = orig_argv


def start_glue_job(glue_client, job_name: str) -> str:
    """Start a Glue job run and return the JobRunId."""
    try:
        response = glue_client.start_job_run(JobName=job_name)
        run_id = response["JobRunId"]
        print(f"  [OK] Started Glue Job '{job_name}' (RunId: {run_id})")
        return run_id
    except ClientError as e:
        print(f"  [FAIL] Failed to start Glue Job '{job_name}': {e}")
        return ""


def check_job_status(glue_client, job_name: str, run_id: str) -> str:
    """Get the current run status of a Glue job."""
    try:
        response = glue_client.get_job_run(JobName=job_name, RunId=run_id)
        return response["JobRun"]["JobRunState"]
    except ClientError as e:
        print(f"  [FAIL] Failed to get status for job '{job_name}' run '{run_id}': {e}")
        return "UNKNOWN"


def monitor_jobs(glue_client, active_runs: dict, poll_interval_sec: int = 30) -> bool:
    """
    Monitor active Glue Job runs until all reach a terminal state.

    active_runs: dict mapping job_name to run_id
    """
    print(f"\nMonitoring Glue job executions (polling every {poll_interval_sec}s)...")
    pending_jobs = dict(active_runs)
    results = {}

    terminal_states = ["SUCCEEDED", "FAILED", "STOPPED", "TIMEOUT"]

    while pending_jobs:
        time.sleep(poll_interval_sec)
        completed = []

        for job_name, run_id in pending_jobs.items():
            status = check_job_status(glue_client, job_name, run_id)
            timestamp = datetime.now().strftime("%H:%M:%S")
            print(f"  [{timestamp}] Job '{job_name}' status: {status}")

            if status in terminal_states:
                results[job_name] = status
                completed.append(job_name)

        for job_name in completed:
            del pending_jobs[job_name]

    print("\nGlue Jobs Execution Finished:")
    all_success = True
    for job_name, status in results.items():
        icon = "[PASS]" if status == "SUCCEEDED" else "[FAIL]"
        print(f"  {icon} {job_name} finished with state: {status}")
        if status != "SUCCEEDED":
            all_success = False

    return all_success


def main():
    parser = argparse.ArgumentParser(description="Run the CapVault End-to-End Pipeline.")
    parser.add_argument("--skip-gen", action="store_true", help="Skip local data generation")
    parser.add_argument("--skip-upload", action="store_true", help="Skip data upload to S3")
    parser.add_argument("--skip-deploy", action="store_true", help="Skip deployment of Glue jobs")
    parser.add_argument("--poll-interval", type=int, default=30, help="Glue job status poll interval in seconds")
    args = parser.parse_args()

    print("\n============================================================")
    print("  CapVault End-to-End Data Pipeline Runner")
    print("============================================================")
    print(f"   Timestamp: {datetime.now().isoformat()}")
    print(f"   Region:    {AWS_REGION}")

    # Step 1: Generate Sample Data
    if not args.skip_gen and not args.skip_upload:
        print("\n--- Step 1: Generating Sample Data ---")
        run_command_module(gen_data)
    else:
        print("\n--- Step 1: Generating Sample Data (SKIPPED) ---")

    # Step 2: Upload Data to S3
    if not args.skip_upload:
        print("\n--- Step 2: Uploading Data to S3 Landing Bucket ---")
        run_command_module(s3_upload, "main", "--clean")
    else:
        print("\n--- Step 2: Uploading Data to S3 Landing (SKIPPED) ---")

    # Step 3: Deploy/Update Glue Jobs
    if not args.skip_deploy:
        print("\n--- Step 3: Deploying Glue Jobs to AWS ---")
        run_command_module(deploy_jobs)
    else:
        print("\n--- Step 3: Deploying Glue Jobs (SKIPPED) ---")

    # Step 4 & 5: Trigger Glue Jobs
    print("\n--- Step 4: Triggering AWS Glue ETL Jobs ---")
    glue = boto3.client("glue", region_name=AWS_REGION)

    active_runs = {}

    pos_run_id = start_glue_job(glue, GLUE_JOB_POSITIONS_ETL)
    if pos_run_id:
        active_runs[GLUE_JOB_POSITIONS_ETL] = pos_run_id

    txn_run_id = start_glue_job(glue, GLUE_JOB_TRANSACTIONS_ETL)
    if txn_run_id:
        active_runs[GLUE_JOB_TRANSACTIONS_ETL] = txn_run_id

    if not active_runs:
        print("\n[FAIL] No Glue jobs could be started. Exiting.")
        sys.exit(1)

    # Step 6: Monitor Jobs
    success = monitor_jobs(glue, active_runs, args.poll_interval)

    if success:
        print("\n[OK] Pipeline completed successfully!")
        print("     You can now run 'python scripts/validate_results.py' to verify the Glue catalog tables.")
    else:
        print("\n[FAIL] Pipeline completed with errors. Check AWS CloudWatch logs for details.")
        sys.exit(1)


if __name__ == "__main__":
    main()
