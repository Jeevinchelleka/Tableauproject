"""
Enhanced Diagnostics Script -- CapVault Pipeline
===================================================
Finds the exact CloudWatch log streams for the failed runs of the Glue jobs
and prints the error traceback.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    GLUE_JOB_POSITIONS_ETL,
    GLUE_JOB_TRANSACTIONS_ETL,
)


def get_glue_client():
    return boto3.client("glue", region_name=AWS_REGION)


def get_logs_client():
    return boto3.client("logs", region_name=AWS_REGION)


def get_latest_failed_run(glue_client, job_name: str) -> tuple:
    """Get the latest failed job run ID."""
    try:
        response = glue_client.get_job_runs(JobName=job_name, MaxResults=5)
        runs = response.get("JobRuns", [])
        for run in runs:
            if run.get("JobRunState") == "FAILED":
                return run.get("Id"), run.get("ErrorMessage", "")
        return None, None
    except Exception as e:
        print(f"Error getting runs for {job_name}: {e}")
        return None, None


def print_log_stream_events(logs_client, log_group: str, stream_prefix: str) -> bool:
    """Finds log streams matching the prefix and prints all their events."""
    try:
        # List streams matching the prefix (the Glue Job Run ID)
        streams_response = logs_client.describe_log_streams(
            logGroupName=log_group,
            logStreamNamePrefix=stream_prefix,
            limit=5
        )
        streams = streams_response.get("logStreams", [])
        if not streams:
            return False

        for stream in streams:
            stream_name = stream["logStreamName"]
            print(f"\n      Log Stream: {stream_name}")
            print(f"      " + "-" * 50)
            
            # Fetch events
            events_response = logs_client.get_log_events(
                logGroupName=log_group,
                logStreamName=stream_name,
                limit=100,
                startFromHead=True
            )
            events = events_response.get("events", [])
            
            # Print lines showing errors/tracebacks, or print the last 20 lines if no obvious error pattern
            error_lines = []
            all_lines = []
            
            for event in events:
                msg = event.get("message", "").strip()
                all_lines.append(msg)
                if any(term in msg for term in ["Exception", "Error", "Traceback", "FAILED", "Cause", "invalid", "cannot"]):
                    error_lines.append(msg)
            
            if error_lines:
                print("      Found Error/Traceback Indicators:")
                for line in error_lines[-30:]: # Print last 30 error lines
                    print(f"        {line}")
            else:
                print("      No explicit Error words found. Showing last 20 lines of logs:")
                for line in all_lines[-20:]:
                    print(f"        {line}")
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] != "ResourceNotFoundException":
            print(f"      [WARN] Error reading log group {log_group}: {e}")
        return False


def main():
    print("\n[DIAGNOSTICS] Fetching detailed tracebacks from CloudWatch...")
    glue = get_glue_client()
    logs = get_logs_client()

    jobs = [GLUE_JOB_POSITIONS_ETL, GLUE_JOB_TRANSACTIONS_ETL]
    
    # Standard Glue log groups:
    # 1. /aws-glue/jobs/logs-v2 (Continuous logging for Glue 3.0/4.0)
    # 2. /aws-glue/jobs/error (Legacy standard error)
    # 3. /aws-glue/jobs/output (Legacy standard output)
    log_groups = [
        "/aws-glue/jobs/logs-v2",
        "/aws-glue/jobs/error",
        "/aws-glue/jobs/output"
    ]

    for job_name in jobs:
        print(f"\n============================================================")
        print(f" Job: {job_name}")
        print(f"============================================================")
        
        run_id, console_err = get_latest_failed_run(glue, job_name)
        if not run_id:
            print("  No failed runs found.")
            continue

        print(f"  Failed Run ID:  {run_id}")
        if console_err:
            print(f"  Console Error:  {console_err}")
            
        found_logs = False
        for log_group in log_groups:
            print(f"  Checking log group: {log_group}...")
            if print_log_stream_events(logs, log_group, run_id):
                found_logs = True
                
        if not found_logs:
            print("\n  [WARN] No log streams found in CloudWatch. Suggestions:")
            print("   1. Check if the Glue IAM Role has logs:PutLogEvents permission.")
            print("   2. Verify in the AWS Glue console under the 'Runs' tab if logs are visible.")

    print("\n============================================================\n")


if __name__ == "__main__":
    main()
