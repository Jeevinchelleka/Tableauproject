"""
Data Validation Script -- CapVault Pipeline
==============================================
Runs Athena queries to count and validate records in the curated Iceberg tables
(position_good, position_bad, transaction_good, transaction_bad).

Ensures that:
  - Data is correctly partitioned
  - No data is lost (total raw count matches curated good + bad counts)
  - Data quality routing has placed records in both tables

Usage:
    python scripts/validate_results.py
"""

import sys
import os
import time
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import boto3
from botocore.exceptions import ClientError

from config.aws_config import (
    AWS_REGION,
    S3_CURATED_BUCKET,
    GLUE_DATABASE,
    GLUE_TABLE_POSITION_GOOD,
    GLUE_TABLE_POSITION_BAD,
    GLUE_TABLE_TRANSACTION_GOOD,
    GLUE_TABLE_TRANSACTION_BAD,
)


def get_athena_client():
    """Create and return an Athena client."""
    return boto3.client("athena", region_name=AWS_REGION)


def run_athena_query(athena_client, query: str, database: str, output_s3_uri: str) -> list:
    """
    Execute an Athena query and wait for it to complete. Returns query results.
    """
    try:
        response = athena_client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={"Database": database},
            ResultConfiguration={"OutputLocation": output_s3_uri}
        )
        query_execution_id = response["QueryExecutionId"]
    except ClientError as e:
        print(f"  [FAIL] Failed to submit query: {e}")
        return []

    # Poll for query completion
    status = "QUEUED"
    max_retries = 30
    retries = 0

    while status in ["QUEUED", "RUNNING"] and retries < max_retries:
        try:
            execution = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
            status = execution["QueryExecution"]["Status"]["State"]
            if status in ["SUCCEEDED", "FAILED", "CANCELLED"]:
                break
        except ClientError as e:
            print(f"  [WARN] Error getting query execution: {e}")
        time.sleep(2)
        retries += 1

    if status != "SUCCEEDED":
        # Get query execution failure reason
        try:
            execution = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
            reason = execution["QueryExecution"]["Status"].get("StateChangeReason", "Unknown reason")
            print(f"  [FAIL] Query execution {query_execution_id} failed with state {status}: {reason}")
        except Exception:
            print(f"  [FAIL] Query execution {query_execution_id} failed with state {status}")
        return []

    # Retrieve results
    try:
        results_paginator = athena_client.get_paginator("get_query_results")
        results_iter = results_paginator.paginate(QueryExecutionId=query_execution_id)

        rows = []
        for results in results_iter:
            for row in results["ResultSet"]["Rows"]:
                # Parse row data
                rows.append([val.get("VarCharValue", "") for val in row["Data"]])
        return rows
    except ClientError as e:
        print(f"  [FAIL] Failed to retrieve results for execution {query_execution_id}: {e}")
        return []


def get_record_count(athena_client, database: str, table: str, output_s3_uri: str) -> int:
    """Get total record count for a table using Athena."""
    query = f"SELECT COUNT(*) FROM {table}"
    results = run_athena_query(athena_client, query, database, output_s3_uri)
    # The first row is the header, the second row contains the count
    if len(results) > 1 and len(results[1]) > 0:
        try:
            return int(results[1][0])
        except ValueError:
            return 0
    return 0


def get_bad_records_breakdown(athena_client, database: str, table: str, output_s3_uri: str) -> list:
    """Get breakdown of failure reasons in a bad table."""
    # Split the pipeline concatenated failure reason and aggregate counts
    query = f"""
    SELECT dq_failure_reason, COUNT(*) as count 
    FROM {table} 
    GROUP BY dq_failure_reason
    ORDER BY count DESC
    LIMIT 10
    """
    results = run_athena_query(athena_client, query, database, output_s3_uri)
    # Return rows after header
    if len(results) > 1:
        return results[1:]
    return []


def main():
    print("\n[VALIDATE] CapVault - Curated Iceberg Data Validation")
    print(f"   Region:   {AWS_REGION}")
    print(f"   Database: {GLUE_DATABASE}")

    athena = get_athena_client()

    # Query results destination in S3
    output_s3_uri = f"s3://{S3_CURATED_BUCKET}/athena-results/"

    print(f"   Query Results Location: {output_s3_uri}")

    tables = {
        "positions_good": GLUE_TABLE_POSITION_GOOD,
        "positions_bad": GLUE_TABLE_POSITION_BAD,
        "transactions_good": GLUE_TABLE_TRANSACTION_GOOD,
        "transactions_bad": GLUE_TABLE_TRANSACTION_BAD,
    }

    counts = {}

    print("\nQuerying table record counts via Athena...")
    for label, table_name in tables.items():
        print(f"  Querying count for table '{table_name}'...")
        count = get_record_count(athena, GLUE_DATABASE, table_name, output_s3_uri)
        counts[label] = count
        print(f"  [OK] Table '{table_name}' count: {count}")

    # Summary calculations
    pos_good = counts["positions_good"]
    pos_bad = counts["positions_bad"]
    pos_total = pos_good + pos_bad

    txn_good = counts["transactions_good"]
    txn_bad = counts["transactions_bad"]
    txn_total = txn_good + txn_bad

    print("\n" + "="*60)
    print("  CapVault Curated Data Quality Report")
    print("="*60)

    print("\n  POSITIONS:")
    print(f"    Good Records:  {pos_good} ({100*pos_good/pos_total:.1f}% of total)" if pos_total else "    Good Records:  0")
    print(f"    Bad Records:   {pos_bad} ({100*pos_bad/pos_total:.1f}% of total)" if pos_total else "    Bad Records:   0")
    print(f"    Total Curated: {pos_total}")

    print("\n  TRANSACTIONS:")
    print(f"    Good Records:  {txn_good} ({100*txn_good/txn_total:.1f}% of total)" if txn_total else "    Good Records:  0")
    print(f"    Bad Records:   {txn_bad} ({100*txn_bad/txn_total:.1f}% of total)" if txn_total else "    Bad Records:   0")
    print(f"    Total Curated: {txn_total}")

    # Print failure reason breakdown for positions_bad
    if pos_bad > 0:
        print("\n  Top Position Data Quality Failures:")
        reasons = get_bad_records_breakdown(athena, GLUE_DATABASE, GLUE_TABLE_POSITION_BAD, output_s3_uri)
        for reason, count in reasons:
            print(f"    - [{count} records] {reason}")

    # Print failure reason breakdown for transactions_bad
    if txn_bad > 0:
        print("\n  Top Transaction Data Quality Failures:")
        reasons = get_bad_records_breakdown(athena, GLUE_DATABASE, GLUE_TABLE_TRANSACTION_BAD, output_s3_uri)
        for reason, count in reasons:
            print(f"    - [{count} records] {reason}")

    print("="*60 + "\n")


if __name__ == "__main__":
    main()
