"""
AWS Configuration for CapVault Pipeline
========================================
Centralised configuration for all AWS resource names, regions,
and connection parameters used across the pipeline.

IMPORTANT: The RDS password is read from the RDS_PASSWORD environment
           variable (set via a .env file in the project root, loaded
           automatically below). AWS Secrets Manager is supported as an
           optional fallback only, and is not required.
"""

import os
import json
import boto3
from botocore.exceptions import ClientError

from dotenv import load_dotenv
load_dotenv()

# ---------------------------------------------------------------------------
# AWS Region
# ---------------------------------------------------------------------------
AWS_REGION = os.getenv("AWS_REGION", "ap-south-1")

# ---------------------------------------------------------------------------
# S3 Buckets
# ---------------------------------------------------------------------------
S3_LANDING_BUCKET = "wealthbridge-landing"
S3_CURATED_BUCKET = "wealthbridge-curated"

# S3 prefixes for data organisation
S3_POSITIONS_PREFIX = "positions/"
S3_TRANSACTIONS_PREFIX = "transactions/"

# S3 prefix for Glue job scripts
S3_GLUE_SCRIPTS_PREFIX = "glue-scripts/"

# Iceberg warehouse location — stored inside the curated bucket
S3_ICEBERG_WAREHOUSE = f"s3://{S3_CURATED_BUCKET}/iceberg-warehouse/"

# ---------------------------------------------------------------------------
# AWS Glue
# ---------------------------------------------------------------------------
GLUE_DATABASE = "iceberg_db"

# Iceberg table names
GLUE_TABLE_POSITION_GOOD = "position_good"
GLUE_TABLE_POSITION_BAD = "position_bad"
GLUE_TABLE_TRANSACTION_GOOD = "transaction_good"
GLUE_TABLE_TRANSACTION_BAD = "transaction_bad"

# Glue job names
GLUE_JOB_POSITIONS_ETL = "capvault-positions-etl"
GLUE_JOB_TRANSACTIONS_ETL = "capvault-transactions-etl"

# Glue job IAM role
GLUE_IAM_ROLE = "arn:aws:iam::194089666490:role/AWSGlueServiceRole-CapVault"

# Glue job worker configuration
GLUE_WORKER_TYPE = "G.1X"
GLUE_NUM_WORKERS = 2
GLUE_TIMEOUT_MINUTES = 30
GLUE_VERSION = "4.0"

# ---------------------------------------------------------------------------
# Aurora / RDS — connection parameters
# ---------------------------------------------------------------------------
RDS_CLUSTER_IDENTIFIER = "wealthbridgemetadatards"
RDS_HOST = os.getenv("RDS_HOST", "wealthbridgemetadatards.cpckkgcwoy32.ap-south-1.rds.amazonaws.com")
RDS_PORT = int(os.getenv("RDS_PORT", "5432"))
RDS_DATABASE_NAME = os.getenv("RDS_DATABASE_NAME", "WealthBridgeMetadataDatabase")
RDS_USER = os.getenv("RDS_USER", "capvolt")

# Secrets Manager secret name — only used as an optional fallback
RDS_SECRET_NAME = "capvault/rds/credentials"


# ---------------------------------------------------------------------------
# RDS Password Resolution
# ---------------------------------------------------------------------------

def get_rds_password(secret_name: str = RDS_SECRET_NAME, region: str = AWS_REGION) -> str:
    """
    Retrieve the RDS password.

    Order of precedence:
      1. RDS_PASSWORD environment variable (set via .env, loaded above)
      2. AWS Secrets Manager (only used if RDS_PASSWORD is not set)

    Returns:
        The RDS password as a string.

    Raises:
        RuntimeError if the password cannot be resolved from either source.
    """
    env_password = os.getenv("RDS_PASSWORD")
    if env_password:
        return env_password

    client = boto3.client("secretsmanager", region_name=region)
    try:
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response["SecretString"])
        return secret["password"]
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        raise RuntimeError(
            f"[ERROR] RDS_PASSWORD env var not set, and could not retrieve secret "
            f"'{secret_name}' from Secrets Manager: {error_code} — {e.response['Error']['Message']}. "
            "Set RDS_PASSWORD in your .env file instead."
        ) from e
    except KeyError:
        raise RuntimeError(
            f"[ERROR] Secret '{secret_name}' does not contain a 'password' key."
        )


_rds_password_cache: str = None


def get_cached_rds_password() -> str:
    """Return the RDS password, resolving it only once per process."""
    global _rds_password_cache
    if _rds_password_cache is None:
        _rds_password_cache = get_rds_password()
    return _rds_password_cache


# ---------------------------------------------------------------------------
# Data Schemas — field definitions for validation & generation
# ---------------------------------------------------------------------------
POSITION_FIELDS = [
    "position_id",
    "account_id",
    "security_id",
    "security_name",
    "quantity",
    "market_value",
    "cost_basis",
    "currency",
    "asset_class",
    "position_date",
    "custodian",
    "portfolio_id",
]

TRANSACTION_FIELDS = [
    "transaction_id",
    "account_id",
    "security_id",
    "security_name",
    "transaction_type",
    "quantity",
    "price",
    "amount",
    "currency",
    "trade_date",
    "settlement_date",
    "broker",
    "portfolio_id",
]

# Valid enum values used across DQ and data generation
VALID_CURRENCIES = ["USD", "EUR", "GBP", "INR", "JPY"]
VALID_TRANSACTION_TYPES = ["BUY", "SELL", "DIVIDEND", "TRANSFER"]
VALID_ASSET_CLASSES = ["EQUITY", "FIXED_INCOME", "COMMODITY", "FOREX", "DERIVATIVE"]


# ---------------------------------------------------------------------------
# Helper — build full S3 URIs
# ---------------------------------------------------------------------------

def s3_landing_uri(prefix: str = "") -> str:
    """Return the full S3 URI for the landing bucket."""
    return f"s3://{S3_LANDING_BUCKET}/{prefix}"


def s3_curated_uri(prefix: str = "") -> str:
    """Return the full S3 URI for the curated bucket."""
    return f"s3://{S3_CURATED_BUCKET}/{prefix}"